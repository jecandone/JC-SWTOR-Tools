import csv
import os

def create_name_mapping(armor_nodes_file):
    """
    Creates a dictionary mapping from node ID to English name
    from ArmorNodes_Names.csv
    """
    mapping = {}
    with open(armor_nodes_file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) >= 3:
                node_id = row[0]
                english_name = row[2]
                mapping[node_id] = english_name
    return mapping

def process_armor_values(input_file, output_file, name_mapping):
    """
    Processes ippArmorValues.csv and creates a new file with updated names.
    When no mapping exists, the node ID (first column) is enclosed in brackets.
    """
    with open(input_file, 'r', encoding='utf-8') as infile, \
         open(output_file, 'w', encoding='utf-8', newline='') as outfile:
        
        reader = csv.reader(infile)
        writer = csv.writer(outfile)
        
        for row in reader:
            if len(row) >= 6:  # Ensure row has all expected columns
                node_id = row[0]
                # If mapping exists, use it; otherwise bracket the node ID
                if node_id in name_mapping:
                    row[1] = name_mapping[node_id]
                else:
                    row[1] = f"[{node_id}]"
                writer.writerow(row)
            else:
                # Write original row if it doesn't have expected number of columns
                writer.writerow(row)

def main():
    # Define file paths
    armor_nodes_file = "ArmorNodes_Names.csv"
    armor_values_file = "ippArmorValues.csv"
    output_file = "ippArmorValues_en.csv"
    
    try:
        # Create mapping from ArmorNodes_Names.csv
        name_mapping = create_name_mapping(armor_nodes_file)
        
        # Process the armor values file and create new file
        process_armor_values(armor_values_file, output_file, name_mapping)
        
        print(f"Successfully created {output_file}")
        
    except FileNotFoundError as e:
        print(f"Error: Could not find file - {e.filename}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()