import csv
import os

def sort_csv(file_name, column_index):
    base_name, ext = os.path.splitext(file_name)
    sorted_file_name = f"{base_name}_sorted{ext}"
    
    with open(file_name, mode='r', newline='') as file:
        reader = csv.reader(file)
        header = next(reader)
        sorted_rows = sorted(reader, key=lambda row: row[column_index])
    
    with open(sorted_file_name, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(sorted_rows)

    return sorted_file_name

if __name__ == "__main__":
    file_name = input("Enter the CSV file name: ")
    column_index = int(input("Enter the column index to sort by (0 for first column): "))
    sorted_file_name = sort_csv(file_name, column_index)
    print(f"Sorted CSV file saved as: {sorted_file_name}")
