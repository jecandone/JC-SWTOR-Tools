------------------------------------------------------------------------------------------------------
Step 3 - Combining ITM and IPP Data
------------------------------------------------------------------------------------------------------

Use Tools in Zip File: Get_ArmorData_3_IPPData.zip

Pre-Reqs

Ensure that the "ippArmorValues.csv" file from the IPP process and the "ArmorNodes_Names.csv" file from the ITM process are inside the folder that "1_CreateNameFile.py" is in.

1) 1_CreateNameFile.py

Creates a new "ippArmorValues.csv" file called "ippArmorValues_en" - replaces Column #2 with the in-game names from the "ArmorNodes_Names.csv" files.  Note: If no matching in game name is found, it uses the FQN name inside of square brackets.

One would be able to do this for other non-English languages to get the names to show up in Blender if they load the non-English version into the Jedipedia file reader, and run the ITM process.  More on how to place this in the plugin and what code would need to be modified in the step after next.

2) 2_Sorting.py

Sorts the CSV files based on column - the script will ask to type in the CSV file to sort (ie "ippArmorValues_en.csv"), and ask which column to sort by.  To sort by in-game names, use type in "1" (Column 0 is first column, Column 1 is 2nd column).  

3) Place inside of Plugin Folder

Take the "ippArmorValues_en_sorted.csv" file, place it inside the "ArmorIPP" folder of the plugin, and remove the "_sorted" part from the file name.

4) OPTIONAL - Additional Languages

If a non-English "ArmorNodes_Names.csv" is used, one would need to run Step 1 above, then change the file name from "ippArmorValues_en.csv" to say for Spanish "ippArmorValues_sp.csv" - the exact name for the non-English file does not matter, this will be changed in the code of the plugin.  Run the sorting function, then place the file inside of the "ArmorIPP" folder of the plugin, and removed the "_sorted" at the end of the file name.

To add this to the code of the plugin, 

	1) Go to the register function at the very end of the code (ie 'def register():'), and then go to the armor_language property (ie 'bpy.types.Scene.armor_language')

	2) The plugin currently has "FQN" and "English", to add a language, add a new line to the items dictionary (ie the 'items=[' part).  There are three columns - the first column is the reference name in the code, the second column is what will display in Blender, and the third column is the description column (ie the text that appears when you hover the mouse over the choice)

	For example, adding a French language, the code for the items dictionary would be

            ('FQN', "FQN", "Display Armor Names as FQN"),
            ('ENGLISH', "English", "Display Armor Names - English")  
	    ('FRENCH', "French", "Afficher les noms d'armures - Français") 	 


	3) go to the "get_armor_csv_path" function (ie 'def get_armor_csv_path(context):'), the function contains an example, a  commented out section for adding in a French langauge, one would do this for whichever languge(s) they would like to add.  

