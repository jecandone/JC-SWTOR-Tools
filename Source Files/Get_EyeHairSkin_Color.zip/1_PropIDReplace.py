import os
import json
from pathlib import Path

def pretty_print_json_file(input_file_path, output_file_path):
    with open(input_file_path, 'r') as file:
        data = json.load(file)
    with open(output_file_path, 'w') as file:
        json.dump(data, file, indent=4)

def process_json_files_in_directory(directory):
    files_processed = 0

    for filename in os.listdir(directory):
        if filename.endswith("_raw.json"):
            raw_file_path = os.path.join(directory, filename)
            new_filename = filename.replace("_raw", "")  # Remove '_raw' from filename
            new_file_path = os.path.join(directory, new_filename)
            pretty_print_json_file(raw_file_path, new_file_path)  # Save as new file
            print(f"Running JSON Pretty Function: {filename} -> {new_filename}")
            files_processed += 1
    
    if files_processed == 0:
        print("No JSON files ending in '_raw.json' found in the directory.")
    
    return files_processed

def process_json_file(input_file_path, mapping_file_path):
    """Process a single JSON file with the given mapping file."""
    with open(input_file_path, 'r') as file:
        base_data = json.load(file)
    with open(mapping_file_path, 'r') as file:
        mapping_data = json.load(file)

    def replace_values(data, mapping):
        if isinstance(data, dict):
            return {key: replace_values(value, mapping) for key, value in data.items()}
        elif isinstance(data, list):
            return [replace_values(item, mapping) for item in data]
        elif isinstance(data, (int, float, str)):
            return mapping.get(data, data)
        else:
            return data

    updated_data = replace_values(base_data, mapping_data)
    output_file_path = str(input_file_path).replace('_raw.json', '.json')

    with open(output_file_path, 'w') as file:
        json.dump(updated_data, file, indent=4)

    print(f"Replacing Names: {input_file_path} -> {output_file_path}")

def process_directory(directory_path, mapping_file_path):
    """Process all _raw.json files in the specified directory."""
    dir_path = Path(directory_path)
    
    if not dir_path.exists():
        raise ValueError(f"Directory not found: {directory_path}")
    
    if not Path(mapping_file_path).exists():
        raise ValueError(f"Mapping file not found: {mapping_file_path}")

    raw_files = list(dir_path.glob('*_raw.json'))
    
    if not raw_files:
        print(f"No '_raw.json' files found in {directory_path}")
        return

    print(f"Found {len(raw_files)} raw JSON files to process")
    
    for file_path in raw_files:
        new_file_path = str(file_path).replace('_raw.json', '.json')
        pretty_print_json_file(file_path, new_file_path)
        print(f"Running JSON Pretty Function: {file_path.name} -> {new_file_path}")

    for file_path in raw_files:
        try:
            process_json_file(file_path, mapping_file_path)
        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")

# Configuration
INPUT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))  # Use current directory
MAPPING_FILE = r"GOM.fields.json"

if __name__ == "__main__":
    try:
        process_directory(INPUT_DIRECTORY, MAPPING_FILE)
    except Exception as e:
        print(f"Error: {str(e)}")
