import os
import glob
import json
import re
import csv
import time
import ast
import struct
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed

# =============================================================================
# Combined PCS + Eye/Hair/Skin color + Head Races + Armor Items (IPP/ITM) +
# Dye Colors + Function Rename pipeline.
#
# Folder layout - everything lives next to this script:
#   Raw_PCS/                      - pcs.*.json downloads
#   Raw_EyeColor/                  - dynamic.eyecolor.*.json downloads
#   Raw_HairColor/                 - dynamic.haircolor.*.json downloads
#   Raw_SkinColor/                 - dynamic.skincolor.*.json downloads
#   Raw_IPP/                       - ipp.*.json downloads (armor appearance nodes)
#   Raw_ITM/                       - itm.*.json downloads (armor item nodes)
#   GOM.fields.json                 - shared field-ID mapping, used by every pipeline
#   ITMNameValues.json              - item name string-ID -> text dictionary (English), used
#                                      by the Armor Items pipeline to resolve ITM display names
#   Raw_Langs/                      - OPTIONAL. Raw str.itm.stb files for additional
#                                      languages, e.g. ITMNameValues_French.stb,
#                                      ITMNameValues_German.stb - downloaded via
#                                      swtor.jedipedia.net's /reader tool ("Original"
#                                      download link on that file's page, NOT the ".txt"
#                                      link - the raw binary is what gets parsed here).
#                                      One additional ippArmorValues_<code>.csv gets
#                                      written per file found here - see Armor Items
#                                      pipeline notes further down for the binary format
#                                      and the language-code naming (German -> "gr", not
#                                      "de", per your convention).
#   itmAppearanceColorsPrototype.json - raw dye-scheme node, used by the Dye Colors pipeline
#   ColorNameValues.json            - dye name string-ID -> text dictionary, used by the
#                                      Dye Colors pipeline (from colornames.stb)
#   __init__.py                     - the Blender plugin source (the dev copy you're
#                                      actively editing), used by the Function Rename
#                                      step (guide step 7.0). Note this is a different
#                                      file from the versioned __init__.py the Function
#                                      Rename step writes below - same filename, but
#                                      this one lives here at the "Raw_" folder level
#                                      and is never modified by this script.
#
# On each run, you're asked for the game version (e.g. "791a") and the path
# to the face index.xml folder (i.e. wherever
# "...\resources\art\dynamic\face" is on disk - same prompt as the old
# 1_GetRaceValues.py). Everything gets written into a fresh version-stamped
# folder next to this script:
#
#   jc_swtor_tools_<version>/
#     Char/
#       {Class}/{gender}/{Species}/...        <- PCS per-character CSVs
#       {Class}_{gender}_{Species}.csv        <- PCS "main" raw-text file
#       {Class}_{gender}_{Species}_sliders.csv
#       CharSliderLabels.csv
#       eyecolor/eyecolor.json
#       hair/haircolor.json
#       skincolor/skincolor.json
#       SkinArmorDefault.csv
#       SkinArmorColorsDefault.csv
#       HeadRaces.csv
#     Dyes/
#       DyeColors.csv                          <- Dye Colors pipeline output
#     ArmorIPP/
#       ippArmorValues.csv                     <- Armor Items pipeline output (base IPP
#                                                  data, un-resolved set name)
#       ippArmorValues_en.csv                  <- Armor Items pipeline output (final,
#                                                  name-resolved & sorted; this is the
#                                                  file the plugin's ArmorIPP folder wants)
#       ippArmorValues_<code>.csv              <- one per file found in Raw_Langs/ (e.g.
#                                                  ippArmorValues_fr.csv,
#                                                  ippArmorValues_gr.csv), same format
#     Anim/                                    <- created empty, reserved for future use
#     Blends/                                  <- created empty, reserved for future use
#     __init__.py                              <- Function Rename step output: a versioned
#                                                  copy of the source __init__.py above,
#                                                  ready to drop straight into Blender's
#                                                  addons folder
#   ExtractedNames.txt                          <- Function Rename step output (written next
#                                                  to this script, not inside the version
#                                                  folder) - every function/class/global
#                                                  var/bl_idname/Scene-property name found
#
# This is a merge of ProcessChar.py (itself already a merge of ProcessPCS.py,
# ProcessColorNodes.py, and 1_GetRaceValues.py) with ProcessItems.py (IPP/ITM),
# ProcessDye.py, and FunctionNameReplace.py (guide step 7.0 - folded in
# directly rather than being generated as a separate file each run).
# GOM.fields.json is loaded once at the top and shared by every pipeline
# instead of each one loading its own copy. The Armor Items pipeline writes
# ippArmorValues.csv as soon as the IPP half is available, and the final,
# name-resolved ippArmorValues_en.csv once both halves are available; the
# ITM-only intermediate (ArmorNodes_Names.csv) is never written to disk -
# it's only needed in memory to build the name lookup. The Function Rename
# step reuses the same version_input/normalized version already entered at
# the top of the run, so there's no second version prompt; it still asks
# for a y/N confirmation before writing __init__.py, since that's the actual
# Blender plugin file. See the "Function Rename" section further down for
# the two collision-avoidance fixes (bl_idname strings, and Scene properties
# registered inside register()/unregister()) applied on top of the original
# tool's logic.
# =============================================================================


# -----------------------------------------------------------------------------
# Shared helpers - load raw JSON, translate IDs -> field names using
# GOM.fields.json. Used by the PCS, color, and dye pipelines. Also reused as
# a generic "id/text-delimited dictionary" loader for ITMNameValues.json and
# ColorNameValues.json, which are the same id -> text shape as GOM.fields.json.
# -----------------------------------------------------------------------------

def clean_json_content(content):
    """Remove trailing commas, just in case the exported JSON has any."""
    content = re.sub(r',(\s*})', r'\1', content)
    content = re.sub(r',(\s*])', r'\1', content)
    return content

def load_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        cleaned_content = clean_json_content(content)
        try:
            return json.loads(cleaned_content)
        except json.JSONDecodeError as e:
            print(f"\nJSON Error in {file_path}:")
            print(f"Error message: {str(e)}")
            raise

def load_mapping_file(file_path):
    """Load a GOM.fields.json-shaped file - handles both JSON and plain
    tab/space-delimited text formats. Reused for GOM.fields.json,
    ITMNameValues.json, and ColorNameValues.json - all three are an
    id -> text dictionary, just produced by different browser-console
    one-liners."""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read().strip()

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        print(f"JSON parsing failed for {file_path}, parsing as text file...")

        mapping_data = {}
        lines = content.strip().split('\n')

        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue

            parts = line.split()
            if len(parts) >= 2:
                key_str = parts[0]
                value = ' '.join(parts[1:])

                if key_str.isdigit():
                    mapping_data[int(key_str)] = value
                    mapping_data[key_str] = value
                else:
                    mapping_data[key_str] = value
            else:
                print(f"Warning: Skipping malformed line {line_num}: '{line}'")

        print(f"Successfully parsed {len(lines)} lines from text file")
        return mapping_data

def replace_ids(obj, fields_mapping, path=""):
    """Recursively translate both dict KEYS and leaf string/int VALUES using
    the GOM.fields.json mapping, wherever an exact ID match exists. Data
    values that aren't a known ID (e.g. "1698756") are left untouched."""
    if isinstance(obj, dict):
        new_obj = {}
        for k, v in obj.items():
            new_key = fields_mapping.get(str(k), k)
            if new_key in new_obj:
                print(f"    Warning: key collision at '{path or '/'}' - "
                      f"'{new_key}' already exists. Keeping original id '{k}' instead.")
                new_key = k
            new_obj[new_key] = replace_ids(v, fields_mapping, f"{path}/{new_key}")
        return new_obj
    elif isinstance(obj, list):
        return [replace_ids(item, fields_mapping, path) for item in obj]
    elif isinstance(obj, (str, int)) and str(obj) in fields_mapping:
        return fields_mapping[str(obj)]
    return obj


def write_csv(path, rows):
    # encoding='utf-8' is explicit here (not left to the OS default) because
    # the Armor Items pipeline now writes real French/German text - on
    # Windows the default text encoding is a legacy codepage that can't
    # represent every character those languages use (e.g. French "oe"
    # ligature, various German accented letters), which would either crash
    # with an encoding error or silently corrupt characters without this.
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(rows)


# =============================================================================
# PCS pipeline
# =============================================================================

# appSlotType enum: numeric code -> appSlot* name. This is a fixed game-engine
# enum that can't be derived from the JSON itself (the JSON only ever carries
# the raw numeric code, never the "appSlotHead" name). Entries below were
# confirmed against Bounty Hunter / Female / Cathar reference output. If
# another species/class exposes a code not listed here, the script falls back
# to "appSlotType_<code>" and prints a warning - add the real name once known.
SLOT_TYPE_NAMES = {
    "1": "appSlotAge",
    "5": "appSlotComplexion",
    "7": "appSlotEyeColor",
    "9": "appSlotFaceHair",
    "10": "appSlotFacePaint",
    "11": "appSlotHair",
    "12": "appSlotHairColor",
    "14": "appSlotHead",
    "16": "appSlotSkinColor",
}
_unknown_codes_seen = set()

def slot_type_name(code):
    code = str(code)
    name = SLOT_TYPE_NAMES.get(code)
    if name is None:
        name = f"appSlotType_{code}"
        if code not in _unknown_codes_seen:
            _unknown_codes_seen.add(code)
            print(f"    Warning: unrecognized appAppearanceSlotType code '{code}' "
                  f"- add it to SLOT_TYPE_NAMES if you know its real name")
    return name

CLASS_MAPPING = {
    "bounty_hunter": "BountyHunter",
    "imperial_agent": "ImperialAgent",
    "jedi_consular": "JediConsular",
    "jedi_knight": "JediKnight",
    "sith_inquisitor": "SithSorc",
    "sith_warrior": "SithWarrior",
    "smuggler": "Smuggler",
    "trooper": "Trooper"
}
GENDER_MAPPING = {"female": "f", "male": "m"}
SPECIES_MAPPING = {
    "cathar": "Cathar",
    "chiss": "Chiss",
    "cyborg": "Cyborg",
    "human": "Human",
    "miralukan_legacy": "Miraluken",
    "mirialan_legacy": "Mirialan",
    "nautolan": "Nautolan",
    "rattataki": "Rattataki",
    "sith_legacy": "Sith",
    "togruta": "Togruta",
    "twilek_legacy": "Twilek",
    "chiss_legacy": "Chiss",
    "cyborg_legacy": "Cyborg",
    "rattataki_legacy": "Rattataki"
}

def map_fqn(fqn):
    """fqn like 'pcs.bounty_hunter.female.cathar' -> (Class, gender_letter, Species)"""
    parts = fqn.split(".")
    if len(parts) < 4:
        raise ValueError(f"Unexpected fqn format: {fqn}")
    class_value, gender_value, species_value = parts[1], parts[2], parts[3]

    if species_value.startswith("zabrak"):
        imperial_classes = ["bounty_hunter", "imperial_agent", "sith_inquisitor", "sith_warrior"]
        republic_classes = ["jedi_consular", "jedi_knight", "smuggler", "trooper"]
        if class_value in imperial_classes:
            mapped_species = "ZabrakRep" if species_value.startswith("zabrak_rep") else "ZabrakImp"
        elif class_value in republic_classes:
            mapped_species = "ZabrakImp" if species_value.startswith("zabrak_imp") else "ZabrakRep"
        else:
            mapped_species = "Zabrak"
    else:
        species_clean = species_value.split('_')[0]
        species_clean = ''.join(c for c in species_clean if not c.isdigit()).lower()
        mapped_species = SPECIES_MAPPING.get(species_clean, species_clean.capitalize())

    if mapped_species.endswith("_legacy"):
        mapped_species = mapped_species[:-7]

    class_mapped = CLASS_MAPPING.get(class_value, class_value)
    gender_mapped = GENDER_MAPPING.get(gender_value, gender_value)

    return class_mapped, gender_mapped, mapped_species


def build_skeleton_code_map(data, gender_mapped):
    """Map each giant skeleton-variant ID in appPcsHeadSkeletonMap to its
    short code (bfa/bfn/bfs/bfb for female, bma/bmn/bms/bmb for male), using
    the fixed a/n/s/b position order confirmed for both genders."""
    prefix = "bm" if gender_mapped == "m" else "bf"
    suffix_order = ["a", "n", "s", "b"]
    display_list = data.get("appPcsSkeletonDisplayList", [])
    if len(display_list) != 4:
        print(f"    Warning: expected 4 entries in appPcsSkeletonDisplayList, "
              f"found {len(display_list)} - skeleton code map may be incomplete")
    code_map = {}
    for i, skeleton_id in enumerate(display_list):
        suffix = suffix_order[i] if i < len(suffix_order) else str(i)
        code_map[skeleton_id] = f"{prefix}{suffix}"
    return code_map


def write_skeleton_display_list(data, out_dir, code_map):
    display_list = data.get("appPcsSkeletonDisplayList", [])
    rows = []
    for i, skeleton_id in enumerate(display_list, start=1):
        rows.append([i, "Int", code_map.get(skeleton_id, skeleton_id)])
    write_csv(os.path.join(out_dir, "appPcsSkeletonDisplayList.csv"), rows)


def write_customization_slot_name_ids(data, out_dir):
    name_ids = data.get("appPcsCustomizationSlotNameIds", {})
    entries = sorted(
        ((slot_type_name(code), big_id) for code, big_id in name_ids.items()),
        key=lambda x: x[0]
    )
    rows = []
    for idx, (name, big_id) in enumerate(entries):
        if idx == 0:
            # Original pipeline quirk: first row keeps an extra "Int" middle
            # column, later rows are 2-column. Confirmed against reference output.
            rows.append([name, "Int", big_id])
        else:
            rows.append([name, big_id])
    write_csv(os.path.join(out_dir, "appPcsCustomizationSlotNameIds.csv"), rows)


def write_head_skeleton_map(data, out_dir, code_map):
    head_map = data.get("appPcsHeadSkeletonMap", {})
    translated = sorted(
        ((code_map.get(sk_id, sk_id), slots) for sk_id, slots in head_map.items()),
        key=lambda x: x[0]
    )
    rows = []
    for code, slots in translated:
        rows.append([code, len(slots)])
        for i, slot_num in enumerate(slots, start=1):
            rows.append([i, slot_num])
    write_csv(os.path.join(out_dir, "appPcsHeadSkeletonMap.csv"), rows)


def build_slider_data_rows(slot_data):
    """Given one appPcsCustomizationSlots[<slotnum>] dict, build the
    SliderData_<slotnum>.csv rows in original field order."""
    rows = []
    for field_name, value in slot_data.items():
        if field_name == "_count":
            continue
        if field_name == "appAppearanceSlotType":
            rows.append([field_name, slot_type_name(value)])
        elif isinstance(value, list):
            if not value:
                continue  # empty lists produce no row at all
            for i, item in enumerate(value, start=1):
                rows.append([i, item])
        else:
            rows.append([field_name, value])
    return rows


def write_slider_data_files(data, out_dir):
    slots = data.get("appPcsCustomizationSlots", {})
    for slot_num, slot_data in slots.items():
        rows = build_slider_data_rows(slot_data)
        write_csv(os.path.join(out_dir, f"SliderData_{slot_num}.csv"), rows)


def write_slider_values_files(data, out_dir):
    slider_map = data.get("appPcsSliderMap", {})
    for slot_num, categories in slider_map.items():
        entries = sorted(
            ((slot_type_name(code), items) for code, items in categories.items()),
            key=lambda x: x[0]
        )
        rows = []
        for name, items in entries:
            rows.append([name, len(items)])
            for i, item in enumerate(items, start=1):
                rows.append([i, item])
        write_csv(os.path.join(out_dir, f"sliderValues_{slot_num}.csv"), rows)


# pcs.json is a big-ID -> display-name dictionary, same id->text shape as
# GOM.fields.json/ITMNameValues.json/ColorNameValues.json, but for the
# customization-slot-name IDs found in appPcsCustomizationSlotNameIds
# (things like "Scars", "Complexion", "Hair Color") - a different ID space
# than GOM.fields.json, so it needs its own lookup rather than being merged
# into fields_mapping (merging it would also translate the raw ID wherever
# appPcsCustomizationSlotNameIds is written out as-is, e.g.
# appPcsCustomizationSlotNameIds.csv and the main per-character .csv, which
# your Blender plugin expects to stay a literal number there).
_pcs_names_unmatched = set()

def translate_pcs_name(big_id, pcs_names_mapping):
    name = pcs_names_mapping.get(str(big_id))
    if name is not None:
        return name
    _pcs_names_unmatched.add(str(big_id))
    return big_id


def build_sliders_summary_row(data, class_mapped, gender_mapped, species_mapped, pcs_names_mapping):
    """Reconstructs the single-row *_sliders.csv summary.

    The first element of each slot_info() tuple is a big customization-slot-
    name ID (from appPcsCustomizationSlotNameIds) rather than a GOM field ID,
    so it isn't covered by GOM.fields.json/replace_ids() - it's translated
    here against pcs.json instead. Only affects this summary row (and so
    CharSliderLabels.csv, which is built from these rows) - the raw big ID is
    still what's written to appPcsCustomizationSlotNameIds.csv and the main
    per-character .csv, since that's the literal numeric ID your Blender
    plugin expects there.
    """
    name_ids = data.get("appPcsCustomizationSlotNameIds", {})
    code_to_big_id = dict(name_ids)

    slider_map = data.get("appPcsSliderMap", {})
    slot_categories = next(iter(slider_map.values()), {})

    def slot_info(type_code):
        big_id = code_to_big_id.get(type_code)
        items = slot_categories.get(type_code)
        if items:
            name = translate_pcs_name(big_id, pcs_names_mapping) if big_id is not None else "n/a"
            return (name, "1", str(len(items)))
        return ("n/a", "0", "1")

    skeleton_weights = data.get("appPcsSkeletonRandomWeights", [])
    min_skeleton = "1"
    max_skeleton = str(len(skeleton_weights)) if skeleton_weights else "4"

    code_map = build_skeleton_code_map(data, gender_mapped)
    head_map = data.get("appPcsHeadSkeletonMap", {})
    head_code = "bma" if gender_mapped == "m" else "bfn"
    head_slots = None
    for sk_id, slots in head_map.items():
        if code_map.get(sk_id) == head_code:
            head_slots = slots
            break
    min_head, max_head = ("1", str(len(head_slots))) if head_slots else ("0", "1")

    scars = slot_info("1")
    complexion = slot_info("5")
    eye_color = slot_info("7")
    face_paint = slot_info("10")
    hair = slot_info("11")
    hair_color = slot_info("12")
    skin_color = slot_info("16")
    face_hair = slot_info("9")

    row = [
        class_mapped, gender_mapped.upper(), species_mapped, "Body",
        min_skeleton, max_skeleton, "Head",
        min_head, max_head,
        *scars, *complexion, *eye_color, *face_paint,
        *hair, *hair_color, *skin_color, *face_hair,
        "0", "5"
    ]
    return row


# -----------------------------------------------------------------------------
# "Main" per-character file: {Class}_{gender}_{Species}.csv, in the OLD
# tab-delimited, type-annotated raw-text format your Blender plugin's
# get_head_index_id() (and possibly other functions) parses directly - this
# is a different format from the CSV files above, confirmed against your
# full BountyHunter_f_Cathar reference paste.
# -----------------------------------------------------------------------------

def build_slot_field_lines(slot_data):
    """Format one slot's fields as tab-delimited lines, in original JSON key
    order, matching the old raw-text SliderData layout.

    Rather than matching against a fixed whitelist of field names (which
    broke the moment a class/species combo had a field the reference sample
    didn't - e.g. appAppearanceSlotFxSpecs/FxData on Trooper/Zabrak), this
    goes off the VALUE's shape, same as the already-validated
    build_slider_data_rows() used for SliderData_<slot>.csv:
      - appAppearanceSlotType is always the Enum
      - any list value -> "List of Int", indexed sub-rows if non-empty
      - any scalar value -> "Int"
    The two known always-empty boilerplate fields (the untranslated numeric
    ID, and ippGearFlourishByBodyType) get their confirmed, differently
    worded "(empty)" label instead of the generic one, since that specific
    wording can't be derived from the JSON.
    """
    lines = []
    for field_name, value in slot_data.items():
        if field_name == "_count":
            continue

        if field_name == "appAppearanceSlotType":
            lines.append(f"{field_name}\tEnum\t{slot_type_name(value)}")
        elif isinstance(value, list):
            if value:
                lines.append(f"{field_name}\tList of Int ({len(value)} rows)")
                for i, item in enumerate(value, start=1):
                    lines.append(f"{i}\tInt\t{item}")
            elif field_name == "ippGearFlourishByBodyType":
                # Confirmed always-empty boilerplate field - hardcoded rather than derived.
                lines.append(f"{field_name}\tLookupList indexed by Int of ClassView (empty)")
            elif field_name.isdigit():
                # Untranslated numeric-ID boilerplate field (e.g. 4611686305318334000) -
                # confirmed always-empty in reference output.
                lines.append(f"{field_name}\tLookupList indexed by Int of String (empty)")
            else:
                lines.append(f"{field_name}\tList of Int (empty)")
        elif isinstance(value, dict):
            # Not seen in any reference sample yet - best-effort generic dump,
            # flagged so it can be checked against real output.
            print(f"    Warning: field '{field_name}' in appPcsCustomizationSlots is a nested "
                  f"object - formatting generically, please verify against real reference output")
            items = [(k, v) for k, v in value.items() if k != "_count"]
            lines.append(f"{field_name}\tLookupList indexed by Int of Int ({len(items)} rows)")
            for i, (sub_k, sub_v) in enumerate(items, start=1):
                lines.append(f"{i}\tInt\t{sub_v}")
        else:
            lines.append(f"{field_name}\tInt\t{value}")
    return lines


def build_customization_slots_text(data):
    slots = data.get("appPcsCustomizationSlots", {})
    lines = [f"appPcsCustomizationSlots\tLookupList indexed by Int of ClassView ({len(slots)} rows)"]
    for slot_num in sorted(slots.keys(), key=lambda x: int(x)):
        slot_data = slots[slot_num]
        total = slot_data.get("_count", len(slot_data))
        present = len(slot_data) - (1 if "_count" in slot_data else 0)
        lines.append(f"{slot_num}\tClassView ({present}/{total} fields)")
        lines.extend(build_slot_field_lines(slot_data))
    return lines


def build_slider_map_text(data):
    slider_map = data.get("appPcsSliderMap", {})
    lines = [f"appPcsSliderMap\tLookupList indexed by Int of LookupList ({len(slider_map)} rows)"]
    for slot_num in sorted(slider_map.keys(), key=lambda x: int(x)):
        categories = slider_map[slot_num]
        entries = sorted(
            ((slot_type_name(code), items) for code, items in categories.items()),
            key=lambda x: x[0]
        )
        lines.append(f"{slot_num}\tLookupList indexed by Enum of List ({len(entries)} rows)")
        for name, items in entries:
            lines.append(f"{name}\tList of Int ({len(items)} rows)")
            for i, item in enumerate(items, start=1):
                lines.append(f"{i}\tInt\t{item}")
    return lines


def build_head_skeleton_map_text(data, code_map):
    head_map = data.get("appPcsHeadSkeletonMap", {})
    translated = sorted(
        ((code_map.get(sk_id, sk_id), slots) for sk_id, slots in head_map.items()),
        key=lambda x: x[0]
    )
    lines = [f"appPcsHeadSkeletonMap\tLookupList indexed by Int of List ({len(head_map)} rows)"]
    for code, slots in translated:
        lines.append(f"{code}\tList of Int ({len(slots)} rows)")
        for i, slot_num in enumerate(slots, start=1):
            lines.append(f"{i}\tInt\t{slot_num}")
    return lines


def build_skeleton_display_list_text(data, code_map):
    display_list = data.get("appPcsSkeletonDisplayList", [])
    lines = [f"appPcsSkeletonDisplayList\tList of Int ({len(display_list)} rows)"]
    for i, skeleton_id in enumerate(display_list, start=1):
        lines.append(f"{i}\tInt\t{code_map.get(skeleton_id, skeleton_id)}")
    return lines


def build_customization_slot_name_ids_text(data):
    name_ids = data.get("appPcsCustomizationSlotNameIds", {})
    entries = sorted(
        ((slot_type_name(code), big_id) for code, big_id in name_ids.items()),
        key=lambda x: x[0]
    )
    lines = [f"appPcsCustomizationSlotNameIds\tLookupList indexed by Enum of Int ({len(entries)} rows)"]
    for name, big_id in entries:
        lines.append(f"{name}\tInt\t{big_id}")
    return lines


def build_skeleton_random_weights_text(data):
    weights = data.get("appPcsSkeletonRandomWeights", [])
    lines = [f"appPcsSkeletonRandomWeights\tList of Int ({len(weights)} rows)"]
    for i, value in enumerate(weights, start=1):
        lines.append(f"{i}\tInt\t{value}")
    return lines


def build_main_text_file(data, code_map):
    """Composes the full old-format {Class}_{gender}_{Species}.csv text -
    the six sections in the fixed order confirmed by your reference paste."""
    lines = []
    lines.extend(build_customization_slots_text(data))
    lines.extend(build_slider_map_text(data))
    lines.extend(build_head_skeleton_map_text(data, code_map))
    lines.extend(build_skeleton_display_list_text(data, code_map))
    lines.extend(build_customization_slot_name_ids_text(data))
    lines.extend(build_skeleton_random_weights_text(data))
    return "\n".join(lines) + "\n"


def process_pcs_file(json_path, fields_mapping, char_root, pcs_names_mapping):
    raw_data = load_json_file(json_path)
    data = replace_ids(raw_data, fields_mapping)

    fqn = data.get("_metadata", {}).get("fqn") or data.get("utlTemplateId")
    if not fqn:
        print(f"  Skipping {os.path.basename(json_path)}: no fqn/_metadata found")
        return

    class_mapped, gender_mapped, species_mapped = map_fqn(fqn)
    print(f"  {fqn} -> {class_mapped}_{gender_mapped}_{species_mapped}")

    out_dir = os.path.join(char_root, class_mapped, gender_mapped, species_mapped)
    os.makedirs(out_dir, exist_ok=True)

    code_map = build_skeleton_code_map(data, gender_mapped)

    write_skeleton_display_list(data, out_dir, code_map)
    write_customization_slot_name_ids(data, out_dir)
    write_head_skeleton_map(data, out_dir, code_map)
    write_slider_data_files(data, out_dir)
    write_slider_values_files(data, out_dir)

    sliders_row = build_sliders_summary_row(data, class_mapped, gender_mapped, species_mapped, pcs_names_mapping)
    sliders_path = os.path.join(
        out_dir, f"{class_mapped}_{gender_mapped}_{species_mapped}_sliders.csv"
    )
    write_csv(sliders_path, [sliders_row])

    # "Main" old-format text file - written flat at the Char/ root (not
    # nested under Class/gender/Species) since your Blender plugin's
    # get_head_index_id() reads it from a flat char/ folder by exact filename.
    main_text = build_main_text_file(data, code_map)
    main_path = os.path.join(char_root, f"{class_mapped}_{gender_mapped}_{species_mapped}.csv")
    with open(main_path, 'w') as f:
        f.write(main_text)


def combine_slider_files(char_root):
    """Combine every character's *_sliders.csv under Char/ into CharSliderLabels.csv."""
    sliders_files = glob.glob(os.path.join(char_root, '**', '*_sliders.csv'), recursive=True)

    if not sliders_files:
        print(f"No *_sliders.csv files found under '{char_root}' - skipping CharSliderLabels.csv")
        return

    rows = []
    for file_path in sliders_files:
        with open(file_path, 'r', newline='') as csvfile:
            csvreader = csv.reader(csvfile)
            for row in csvreader:
                if row:  # skip any stray blank lines
                    rows.append(row)

    # Sort alphabetically by Class, then gender, then Species - same as before
    rows.sort(key=lambda x: (x[0], x[1], x[2]))

    output_file = os.path.join(char_root, 'CharSliderLabels.csv')
    with open(output_file, 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        for row in rows:
            csvwriter.writerow(row)

    print(f"\nCombined {len(sliders_files)} sliders file(s) into: {output_file}")


# Filename prefixes to skip entirely - scratch/test/QA nodes that aren't
# real class/gender/species data. Add more here as you find them.
PCS_EXCLUDED_PREFIXES = ("pcs.test", "pcs.qa")


PCS_NAMES_FILENAME = "pcs.json"


def run_pcs_pipeline(script_dir, fields_mapping, char_root):
    print("\n=== PCS ===")
    input_dir = os.path.join(script_dir, "Raw_PCS")

    if not os.path.isdir(input_dir):
        print(f"Warning: 'Raw_PCS' folder not found - skipping PCS pipeline")
        return

    json_files = glob.glob(os.path.join(input_dir, "*.json"))
    if not json_files:
        print(f"No .json files found in '{input_dir}' - skipping PCS pipeline")
        return

    pcs_names_path = os.path.join(script_dir, PCS_NAMES_FILENAME)
    if os.path.isfile(pcs_names_path):
        pcs_names_mapping = load_mapping_file(pcs_names_path)
        print(f"Loaded {len(pcs_names_mapping)} entries from {PCS_NAMES_FILENAME}")
    else:
        print(f"Warning: {PCS_NAMES_FILENAME} not found at {pcs_names_path} - "
              f"customization-slot names in CharSliderLabels.csv will stay as raw numeric IDs")
        pcs_names_mapping = {}

    skipped_test_files = []

    for json_path in json_files:
        filename = os.path.basename(json_path)

        if filename.lower().startswith(PCS_EXCLUDED_PREFIXES):
            skipped_test_files.append(filename)
            continue

        print(f"\nProcessing {filename}...")
        try:
            process_pcs_file(json_path, fields_mapping, char_root, pcs_names_mapping)
        except Exception as e:
            print(f"  Error processing {filename}: {e}")

    if skipped_test_files:
        print(f"\nSkipped {len(skipped_test_files)} test file(s): "
              f"{', '.join(skipped_test_files)}")

    if _unknown_codes_seen:
        print(f"\nWarning: encountered {len(_unknown_codes_seen)} unrecognized "
              f"slot-type code(s) across all files: {sorted(_unknown_codes_seen)}. "
              f"Add them to SLOT_TYPE_NAMES for accurate labeling.")

    if _pcs_names_unmatched:
        sample = sorted(_pcs_names_unmatched)[:10]
        more = f" (+{len(_pcs_names_unmatched) - 10} more)" if len(_pcs_names_unmatched) > 10 else ""
        print(f"\nWarning: {len(_pcs_names_unmatched)} customization-slot-name ID(s) had no "
              f"match in {PCS_NAMES_FILENAME} and were left as raw numbers in "
              f"CharSliderLabels.csv: {sample}{more}")

    combine_slider_files(char_root)


# =============================================================================
# Eye/Hair/Skin color pipeline
# =============================================================================

def build_node_metadata(metadata):
    """Reconstruct the 'node' block from the new format's _metadata, deriving
    path/fileName from the fqn the same way the old bundle scan produced them."""
    fqn = metadata.get("fqn", "")
    prefix, _, last = fqn.rpartition(".")
    path = f"{prefix}." if prefix else ""
    return {
        "id": metadata.get("id"),
        "fqn": fqn,
        "baseClass": metadata.get("baseClass"),
        "path": path,
        "fileName": last,
    }


def build_obj_list(translated_data):
    """Turn the translated flat {fieldName: value} data into the old
    [{"id": fieldName, "type": ..., "value": ...}] list format."""
    obj = []
    for key, value in translated_data.items():
        if key in ("_metadata", "_count"):
            continue
        if isinstance(value, dict):
            # Composite values (e.g. appPaletteSpecular's r/g/b/a) - type 9,
            # matching your reference eyecolor.json
            sub_items = []
            for sub_key, sub_value in value.items():
                if sub_key == "_count":
                    continue
                sub_items.append({"id": sub_key, "type": 4, "val": sub_value})
            obj.append({"id": key, "type": 9, "value": sub_items})
        elif isinstance(value, list):
            # Seen on hair/skin color fields (appPaletteEnvMapAdjust,
            # appPaletteMetallicAdjust) - confirmed against your reference
            # haircolor.json/skincolor.json: type 7, value is a nested
            # {"type": 4, "list": [...]} object (not the type-9 composite
            # dicts use).
            obj.append({"id": key, "type": 7, "value": {"type": 4, "list": value}})
        elif isinstance(value, (int, float)):
            obj.append({"id": key, "type": 4, "value": value})
        else:
            print(f"    Warning: unexpected value type for '{key}' "
                  f"({type(value).__name__}) - including as-is, please verify")
            obj.append({"id": key, "type": 4, "value": value})
    return obj


def detect_category(fqn):
    """'dynamic.haircolor.haircolor_sith_non_h02_p' -> 'haircolor'.
    Returns None if fqn doesn't look like a dynamic.<category>.<name> node."""
    parts = fqn.split(".")
    if len(parts) >= 2 and parts[0] == "dynamic":
        return parts[1]
    return None


def process_color_file(json_path, fields_mapping):
    raw_data = load_json_file(json_path)

    metadata = raw_data.get("_metadata")
    if not metadata:
        print(f"    Skipping {os.path.basename(json_path)}: no _metadata found - "
              f"likely an index/manifest file, not a real color node")
        return None

    fqn = metadata.get("fqn", "")
    parts = fqn.split(".")
    if len(parts) < 3:
        print(f"    Skipping {os.path.basename(json_path)}: fqn '{fqn}' doesn't look "
              f"like a real color node (expected e.g. dynamic.haircolor.<name>)")
        return None
    if parts[-1].lower() == "index":
        print(f"    Skipping {os.path.basename(json_path)}: fqn '{fqn}' looks like a "
              f"directory index, not a real color node")
        return None

    translated = replace_ids(raw_data, fields_mapping)

    # Build "node" from the UNTRANSLATED _metadata - id/fqn/baseClass are
    # identifiers, not field IDs, and shouldn't go through the mapping.
    node = build_node_metadata(metadata)
    obj = build_obj_list(translated)

    return {"node": node, "obj": obj}


# Each Raw_* folder's contents go into their own Char/ subfolder, under the
# filename your Blender plugin already expects.
COLOR_FOLDER_CONFIG = [
    {"raw_folder": "Raw_EyeColor", "category": "eyecolor", "subfolder": "eyecolor"},
    {"raw_folder": "Raw_HairColor", "category": "haircolor", "subfolder": "hair"},
    {"raw_folder": "Raw_SkinColor", "category": "skincolor", "subfolder": "skincolor"},
]


def run_color_pipeline(script_dir, fields_mapping, char_root):
    print("\n=== Eye/Hair/Skin Color ===")

    for config in COLOR_FOLDER_CONFIG:
        raw_folder = os.path.join(script_dir, config["raw_folder"])
        if not os.path.isdir(raw_folder):
            print(f"Warning: '{config['raw_folder']}' folder not found - skipping")
            continue

        json_files = glob.glob(os.path.join(raw_folder, "*.json"))
        print(f"\nFound {len(json_files)} file(s) in {config['raw_folder']}/")
        if not json_files:
            continue

        results = []
        skipped = 0
        for json_path in json_files:
            filename = os.path.basename(json_path)
            print(f"Processing {filename}...")
            try:
                result = process_color_file(json_path, fields_mapping)
                if result is None:
                    skipped += 1
                else:
                    detected = detect_category(result["node"]["fqn"])
                    if detected and detected != config["category"]:
                        print(f"    Warning: '{filename}' looks like '{detected}' data "
                              f"but was found in {config['raw_folder']}/ - writing it to "
                              f"{config['category']}.json anyway, please double check "
                              f"it's not a misplaced file")
                    results.append(result)
            except Exception as e:
                print(f"  Error processing {filename}: {e}")

        if not results:
            if skipped:
                print(f"Skipped {skipped} non-node file(s) in {config['raw_folder']}/")
            continue

        results.sort(key=lambda r: r["node"]["fqn"])

        out_dir = os.path.join(char_root, config["subfolder"])
        os.makedirs(out_dir, exist_ok=True)
        output_path = os.path.join(out_dir, f"{config['category']}.json")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=4)

        print(f"Combined {len(results)} node(s) into: {output_path}")
        if skipped:
            print(f"Skipped {skipped} non-node file(s) in {config['raw_folder']}/")


# =============================================================================
# Head Races (was 1_GetRaceValues.py)
#
# Reads index.xml from the face data folder, pulls every unique Race tag
# value, and writes them sorted, one per row, to Char/HeadRaces.csv - same
# logic as the original script, just writing into Char/ instead of next to
# itself.
#
# The face folder always lives at a fixed subpath under the per-dump
# "resources" folder: resources\art\dynamic\face. Since that subpath never
# changes, get_head_race_directory() only asks for the "resources" folder
# itself (the part that's different every asset dump, e.g.
# ...\Assets_2026.08.15_791a\resources) and appends "art\dynamic\face" to
# it automatically.
# =============================================================================

FACE_INDEX_SUBPATH = ("art", "dynamic", "face")


def get_head_race_directory():
    while True:
        resources_path = input(
            "Path to the 'resources' folder "
            "(e.g. ...\\Assets_2026.08.15_791a\\resources): "
        ).strip()

        if not os.path.isdir(resources_path):
            print("The specified path is not a directory. Please enter a valid directory path.")
            continue

        face_dir = os.path.join(resources_path, *FACE_INDEX_SUBPATH)
        if not os.path.isdir(face_dir):
            print(f"Couldn't find '{os.path.join(*FACE_INDEX_SUBPATH)}' under that folder "
                  f"(looked for: {face_dir}). Make sure this is the 'resources' folder itself.")
            continue

        return face_dir


def write_head_races_csv(directory_path, char_root):
    print("\n=== Head Races ===")
    xml_file_path = os.path.join(directory_path, 'index.xml')
    csv_file_path = os.path.join(char_root, 'HeadRaces.csv')

    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        unique_races = set()
        for tag in root.findall('.//Tag[@name="Race"]'):
            race = tag.get('value')
            if race:
                unique_races.add(race)

        with open(csv_file_path, mode='w', newline='') as csv_file:
            writer = csv.writer(csv_file)
            for race in sorted(unique_races):
                writer.writerow([race])

        print(f"Wrote {len(unique_races)} unique race(s) to {csv_file_path}")

    except FileNotFoundError:
        print(f"  Error: index.xml was not found in '{directory_path}' - skipping HeadRaces.csv")
    except PermissionError:
        print(f"  Error: permission denied reading the XML file - skipping HeadRaces.csv")
    except Exception as e:
        print(f"  Error processing head races: {e} - skipping HeadRaces.csv")


# =============================================================================
# Constant files
#
# These two never change run-to-run - you set the values once and just keep
# copying them forward - so they're just written out verbatim into Char/
# every time, byte-for-byte matching your SkinArmorDefault.csv /
# SkinArmorColorsDefault.csv reference (including the CRLF line endings and
# the lack of a trailing newline on SkinArmorDefault.csv).
# =============================================================================

SKIN_ARMOR_DEFAULT_CSV = (
    "chest,chest_tightskin_[bt]_archetype.gr2,chest_naked_[race]_young_a01c01_[bt],chest_tightskin_non_non_a01underwear02_[gen]\r\n"
    "leg,leg_underwear_[bt]_archetype.gr2,leg_naked_[race]_young_a01c01_[bt],leg_pantskin_non_non_a01underwear02_[gen]_v01\r\n"
    "hand,hand_naked_[bt]_archetype.gr2,hand_naked_[race]_young_a01c01_[bt],n/a\r\n"
    "feet,boot_naked_[bt]_archetype.gr2,boot_naked_[race]_young_a01c01_[bt],n/a"
)

SKIN_ARMOR_COLORS_DEFAULT_CSV = (
    "Default\r\n"
    "hue,0\r\n"
    "saturation,0.5\r\n"
    "brightness,0\r\n"
    "contrast,1\r\n"
    "specular,0,0.5,0,1\r\n"
    "metallicSpecular,0,0.5,0,1\r\n"
    "fleshBrightness,0.1\r\n"
    "flushTone,0.475,0.122,0.122,1\r\n"
    "rattataki\r\n"
    "hue,0\r\n"
    "saturation,0.5\r\n"
    "brightness,0\r\n"
    "contrast,1\r\n"
    "specular,1,1,1,1\r\n"
    "metallicSpecular,1,1,1,1\r\n"
    "fleshBrightness,0.1\r\n"
    "flushTone,0.313726,0.368628,0.631373,1\r\n"
)

CONSTANT_CHAR_FILES = {
    "SkinArmorDefault.csv": SKIN_ARMOR_DEFAULT_CSV,
    "SkinArmorColorsDefault.csv": SKIN_ARMOR_COLORS_DEFAULT_CSV,
}


def write_constant_char_files(char_root):
    print("\n=== Constant files ===")
    for filename, content in CONSTANT_CHAR_FILES.items():
        path = os.path.join(char_root, filename)
        # newline='' so Python doesn't touch the embedded \r\n - written
        # exactly as specified above, matching your reference files.
        with open(path, 'w', newline='') as f:
            f.write(content)
        print(f"Wrote {path}")


# =============================================================================
# Armor Items pipeline (was process_swtor_nodes.py / ProcessItems.py)
#
# Reads:
#     Raw_IPP/*.json    (armor appearance nodes)
#     Raw_ITM/*.json    (armor item nodes)
#     Raw_Langs/*.stb   (OPTIONAL - additional-language name tables, see below)
# Writes (all into ArmorIPP/):
#     ippArmorValues.csv       (base IPP data - FQN, un-resolved set name, slot,
#                                model ID, color scheme, material index - written
#                                as soon as Raw_IPP/ produces rows, independent
#                                of whether the ITM half is available)
#     ippArmorValues_en.csv    (final, name-resolved & sorted - the file the
#                                plugin's ArmorIPP folder wants)
#     ippArmorValues_<code>.csv  (same, one per file found in Raw_Langs/)
#
# Both Raw_IPP/ and Raw_ITM/ are optional - if one is missing or empty, that
# half is simply skipped (with a log message). ippArmorValues.csv only needs
# the IPP half and is written whenever that succeeds; the name-resolved files
# need both halves, so they're only written when both produced rows.
#
# Raw_ITM/ is read from disk exactly ONCE regardless of how many languages
# you end up producing - the appearance/icon/slot data in those files doesn't
# change per language, only the resolved display NAME does (via a different
# name table per language), so re-reading 100k+ files once per language would
# be pure waste. ArmorNodes_Names.csv (the ITM-only intermediate) is never
# written to disk either way - it's only ever needed in memory.
#
# MULTIPLE LANGUAGES (Raw_Langs/)
# --------------------------------
# English names come from ITMNameValues.json (numeric string-table id -> English
# text), same as always. Additional languages come from raw str.itm.stb files -
# not the wiki's item-listing pages, and not a JSON export - the actual binary
# string table SWTOR ships per language, downloaded via swtor.jedipedia.net's
# /reader tool: open Database > Files, drill into resources/<locale>/str/itm.stb
# for the language you want (e.g. resources/de-de/str/itm.stb for German), and
# use the "Original" download link (NOT ".txt" - that strips the IDs and can't
# be reliably realigned). Drop the file into Raw_Langs/ next to this script,
# named so the language is obvious - e.g. ITMNameValues_French.stb,
# ITMNameValues_German.stb (also fine: any filename containing "french"/"fr"
# or "german"/"gr"/"de" as its own word). One ippArmorValues_<code>.csv gets
# written per file found there. German is written as "_gr", not "_de" - your
# convention, kept throughout.
#
# .stb BINARY FORMAT (reverse-engineered from real German/French itm.stb
# files, cross-checked against ~99.4% of ITMNameValues.json's existing id set
# and against the values swtor.jedipedia.net's own reader UI displays):
#   offset 0        : 1 byte    - format/version flag (always seen as 0x01)
#   offset 1-2      : 2 bytes   - unused/reserved
#   offset 3-6      : uint32 LE - total record count
#   offset 7...     : fixed-size 26-byte records, one per (id, grammatical
#                      variant) pair:
#     [0:8]   uint64 LE - the item's Global/string-table id (matches the
#                          numeric id in itmNameEncoded "str.itm#<id>", and
#                          the keys already used in ITMNameValues.json)
#     [8:12]  uint32 LE - "type" code: 0x141 = base/masculine text (the one
#                          we want), 0x146 = feminine grammatical variant
#                          (differs from 0x141 for some titles, e.g. German
#                          "Meisterhandwerker"/"Meisterhandwerkerin" - not
#                          needed here since armor names aren't gendered),
#                          0x41/0x46 = a smaller, unrelated string category.
#     [12:14] constant marker, always seen as 0x3f80 - unused
#     [14:16] uint16 LE - byte length of this record's UTF-8 string (0 = no
#                          text for this id/type combination)
#     [16:18] always seen as 0 - unused/reserved
#     [18:22] uint32 LE - ABSOLUTE file offset (from byte 0 of the file, not
#                          relative to the string blob) where this record's
#                          UTF-8 text begins
#     [22:24] uint16 LE - same length value, repeated
#     [24:26] always seen as 0 - padding
#   after all records: a flat blob of UTF-8 text, back-to-back with no
#   delimiters - only each record's own (offset, length) says where its
#   string starts/ends.
# =============================================================================

PROGRESS_INTERVAL = 1000
IO_WORKERS = 16  # threads for reading/parsing Raw_IPP and Raw_ITM - pure local
                  # disk I/O (no network), so this is safe to raise (e.g. 32-64)
                  # if it helps, or lower if it doesn't (e.g. a slow/spinning disk)

ITM_NAMES_FILENAME = "ITMNameValues.json"
ITEMS_BASE_OUTPUT_FILENAME = "ippArmorValues.csv"
ITEMS_OUTPUT_FILENAME = "ippArmorValues_en.csv"
RAW_LANGS_DIRNAME = "Raw_Langs"

# Filename -> language-code detection for Raw_Langs/*.stb files. Matches
# whole, non-alphabetic-bounded tokens (case-insensitive), so
# "ITMNameValues_French.stb", "ITMNameValues_German.stb", "fr_itm.stb", etc.
# all resolve correctly. German always maps to "gr" (not "de") in the output
# filename, per your convention - "de" is still accepted as an input alias in
# case a file gets named that way, but the CSV it produces is always "_gr".
LANG_STB_ALIASES = {
    "french": "fr", "francais": "fr", "français": "fr", "fr": "fr",
    "german": "gr", "deutsch": "gr", "gr": "gr", "de": "gr",
}

# Manual fixups for FQNs that appear shortened/aliased in the IPP data
# relative to the full path used in the ITM (name) data. Extend this as you
# run across new mismatches (carried over from the original
# 1_CreateNameFile.py create_base_path_mapping()).
BASE_PATH_MAPPING = {
    "ipp.frontline_slicer": "ipp.mtx.season10.frontline_slicer",
}

# Column to sort the final CSV by (0 = FQN, 1 = in-game name, ...). Always
# the in-game name column per your instruction - no interactive prompt.
SORT_COLUMN_INDEX = 1

# baseClass values that mark a node as an IPP appearance node or an ITM item
# node, respectively. Files that don't match get skipped (with a warning) in
# case stray/unrelated files end up in the Raw_IPP/Raw_ITM folders.
IPP_BASE_CLASS = '4611686022221010000'
ITM_BASE_CLASS = '4611686018445921550'

# Translated (English) field names used from each node type, after applying
# the GOM.fields.json mapping to the raw dict's keys.
IPP_FIELD_MODEL_ID = 'appAppearanceSlotModelID'
IPP_FIELD_MATERIAL_INDEX = 'appAppearanceSlotMaterialIndex'
IPP_FIELD_COLOR_SCHEME = 'ippColorScheme'

ITM_FIELD_ICON = 'itmIcon'
ITM_FIELD_NAME_ENCODED = 'itmNameEncoded'

# Matches "str.itm#<id>" as well as variants seen in the wild like
# "str.test.itm#<id>" (a different/less-common string table than the one
# ITMNameValues.json is normally extracted from) - anything of the form
# "str.<word>.<word>...itm#<id>". We only need the trailing numeric id to
# look the name up, regardless of which table prefix precedes it.
STR_ITM_PATTERN = re.compile(r'^str\.(?:\w+\.)*itm#(\d+)$')

# A looser check used only to flag values that clearly look like an
# unresolved string-table reference (start with "str." and contain "itm#")
# but didn't match STR_ITM_PATTERN above - so a future/unknown format gets
# surfaced in the summary log instead of silently leaking raw encoded text
# into the CSV the way "str.test.itm#..." did before STR_ITM_PATTERN was
# broadened to cover it.
LOOKS_LIKE_ITM_REFERENCE = re.compile(r'^str\..*itm#\d+$')


def lookup(mapping, key):
    """Look up a key that might be a numeric string, trying str then int form."""
    if key in mapping:
        return mapping[key]
    if isinstance(key, str) and key.isdigit():
        return mapping.get(int(key))
    return None


def translate_fields(data, field_mapping):
    """
    Rename every field key (excluding the _metadata/_count housekeeping
    keys) using the GOM.fields.json mapping. Unknown keys are left as-is.
    """
    translated = {}
    for key, value in data.items():
        if key in ('_metadata', '_count'):
            continue
        new_key = lookup(field_mapping, key)
        translated[new_key if new_key is not None else key] = value
    return translated


def stringify_value(value):
    """Flatten a field value to a single string for a CSV cell."""
    if isinstance(value, list):
        return ';'.join(str(v) for v in value)
    if value is None:
        return ''
    return str(value)


def extract_name_and_slot(fqn):
    """
    Split an fqn like 'ipp.3x0.bh.massassi.feet' into:
      set_name = 'massassi'  (second-to-last segment)
      slot     = 'feet'      (last segment)
    """
    parts = fqn.split('.')
    slot = parts[-1] if parts else ''
    set_name = parts[-2] if len(parts) >= 2 else ''
    return set_name, slot


def load_files_threaded(file_paths, max_workers=IO_WORKERS):
    """Reads and JSON-parses many files concurrently. Opening and parsing
    tens/hundreds of thousands of small individual files is I/O-bound, not
    CPU-bound - the per-file open() call (plus, on Windows, antivirus
    real-time-scanning every file as it's opened) dominates over the actual
    JSON parsing time. File I/O releases Python's GIL, so a thread pool here
    gets real wall-clock speedup despite being "just Python threads". Yields
    (file_path, data_or_None, error_or_None) in completion order (not
    necessarily input order) - fine here since nothing downstream depends on
    file order."""
    def _load(path):
        try:
            return path, load_json_file(path), None
        except Exception as e:
            return path, None, e

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_load, p) for p in file_paths]
        for fut in as_completed(futures):
            yield fut.result()


def process_ipp_files(raw_directory, field_mapping):
    """Read every Raw_IPP/*.json file and return a list of
    [fqn, set_name, slot, model_id, color_scheme, material_index] rows, or
    None if the folder is missing/empty."""
    if not os.path.isdir(raw_directory):
        print(f"Warning: 'Raw_IPP' folder not found - skipping IPP processing")
        return None

    start = time.perf_counter()
    raw_files = sorted(glob.glob(os.path.join(raw_directory, '*.json')))
    if not raw_files:
        print(f"No .json files found in '{raw_directory}' - skipping IPP processing")
        return None

    total = len(raw_files)
    print(f"[IPP] Found {total} file(s) in {raw_directory} - loading with {IO_WORKERS} threads")

    rows = []
    skipped = 0
    i = 0

    for file_path, data, err in load_files_threaded(raw_files):
        i += 1
        file_name = os.path.basename(file_path)

        if err is not None:
            print(f"  [IPP] Failed to parse {file_name}: {err}")
            skipped += 1
        else:
            metadata = data.get('_metadata', {})
            base_class = metadata.get('baseClass', '')
            fqn = metadata.get('fqn', '')

            if not fqn:
                print(f"  [IPP] Skipping {file_name}: no fqn in _metadata")
                skipped += 1
            elif base_class != IPP_BASE_CLASS:
                print(f"  [IPP] Skipping {file_name}: baseClass '{base_class}' != expected '{IPP_BASE_CLASS}'")
                skipped += 1
            else:
                translated = translate_fields(data, field_mapping)

                set_name, slot = extract_name_and_slot(fqn)
                model_id = stringify_value(translated.get(IPP_FIELD_MODEL_ID, ''))
                material_index = stringify_value(translated.get(IPP_FIELD_MATERIAL_INDEX, ''))
                color_scheme = stringify_value(translated.get(IPP_FIELD_COLOR_SCHEME, ''))

                rows.append([fqn, set_name, slot, model_id, color_scheme, material_index])

        if i % PROGRESS_INTERVAL == 0:
            elapsed = time.perf_counter() - start
            print(f"  [IPP] ...{i}/{total} files ({elapsed:.1f}s elapsed)")

    if not rows:
        print("[IPP] No valid rows produced.")
        return None

    elapsed = time.perf_counter() - start
    print(f"[IPP] Processed {len(rows)} row(s) ({skipped} file(s) skipped) in {elapsed:.2f}s")
    return rows


def resolve_display_name(name_encoded, item_names, fallback, unmatched_ids, unparsed_encoded):
    """
    Resolve an itmNameEncoded value like 'str.itm#3770946926149632' (or the
    'str.test.itm#...' variant, or similar) into its English name via
    ITMNameValues.json. Falls back to `fallback` (the slot) if there's no
    encoded value or no match is found.

    Misses/unparsed values are appended to `unmatched_ids`/`unparsed_encoded`
    instead of being logged individually, so a dataset with thousands of
    them doesn't flood the console - resolve_itm_names() logs summary lines
    at the end instead.
    """
    if isinstance(name_encoded, str):
        match = STR_ITM_PATTERN.match(name_encoded)
        if match:
            item_id = match.group(1)
            resolved = lookup(item_names, item_id)
            if resolved is not None:
                return resolved
            unmatched_ids.append(item_id)
            return fallback
        if LOOKS_LIKE_ITM_REFERENCE.match(name_encoded):
            # Looks like an unresolved string-table reference in a format we
            # don't recognize - don't leak the raw encoded text into the
            # CSV, fall back to the slot name and flag it for review instead.
            unparsed_encoded.append(name_encoded)
            return fallback
        return name_encoded
    return fallback


def process_itm_files_raw(raw_directory, field_mapping):
    """Read every Raw_ITM/*.json file ONCE and return a list of
    [icon_value, slot, name_encoded] rows, or None if the folder is
    missing/empty. This is language-independent - icon/slot/name_encoded
    don't change per language, only what name_encoded resolves TO does - so
    this is called exactly once per run and reused for every language,
    instead of re-reading 100k+ files once per language."""
    if not os.path.isdir(raw_directory):
        print(f"Warning: 'Raw_ITM' folder not found - skipping ITM processing")
        return None

    start = time.perf_counter()
    raw_files = sorted(glob.glob(os.path.join(raw_directory, '*.json')))
    if not raw_files:
        print(f"No .json files found in '{raw_directory}' - skipping ITM processing")
        return None

    total = len(raw_files)
    print(f"[ITM] Found {total} file(s) in {raw_directory} - loading with {IO_WORKERS} threads")

    rows = []
    skipped = 0
    i = 0

    for file_path, data, err in load_files_threaded(raw_files):
        i += 1
        file_name = os.path.basename(file_path)

        if err is not None:
            print(f"  [ITM] Failed to parse {file_name}: {err}")
            skipped += 1
        else:
            metadata = data.get('_metadata', {})
            base_class = metadata.get('baseClass', '')
            fqn = metadata.get('fqn', '')

            if not fqn:
                print(f"  [ITM] Skipping {file_name}: no fqn in _metadata")
                skipped += 1
            elif base_class != ITM_BASE_CLASS:
                print(f"  [ITM] Skipping {file_name}: baseClass '{base_class}' != expected '{ITM_BASE_CLASS}'")
                skipped += 1
            else:
                translated = translate_fields(data, field_mapping)

                icon_value = translated.get(ITM_FIELD_ICON)
                name_encoded = translated.get(ITM_FIELD_NAME_ENCODED)
                slot = fqn.split('.')[-1] if fqn else ''

                if icon_value is None:
                    print(f"  [ITM] Skipping {file_name}: no itmIcon value found")
                    skipped += 1
                else:
                    rows.append([icon_value, slot, name_encoded])

        if i % PROGRESS_INTERVAL == 0:
            elapsed = time.perf_counter() - start
            print(f"  [ITM] ...{i}/{total} files ({elapsed:.1f}s elapsed)")

    if not rows:
        print("[ITM] No valid rows produced.")
        return None

    elapsed = time.perf_counter() - start
    print(f"[ITM] Processed {len(rows)} row(s) ({skipped} file(s) skipped) in {elapsed:.2f}s")
    return rows


def resolve_itm_names(raw_itm_rows, item_names, lang_label):
    """Takes the language-independent [icon_value, slot, name_encoded] rows
    from process_itm_files_raw() and resolves each name_encoded against a
    SPECIFIC language's {id: name} dict (either the English
    ITMNameValues.json, or a language parsed from a Raw_Langs/*.stb file),
    returning [icon_value, slot, display_name] rows - the same shape the old
    single-language process_itm_files() used to return directly. No file I/O
    here, so this is fast even when called once per language."""
    rows = []
    unmatched_ids = []
    unparsed_encoded = []

    for icon_value, slot, name_encoded in raw_itm_rows:
        display_name = resolve_display_name(
            name_encoded, item_names, fallback=slot,
            unmatched_ids=unmatched_ids, unparsed_encoded=unparsed_encoded,
        )
        rows.append([icon_value, slot, display_name])

    if unmatched_ids:
        sample = ', '.join(f'str.itm#{i}' for i in unmatched_ids[:5])
        more = f" (+{len(unmatched_ids) - 5} more)" if len(unmatched_ids) > 5 else ""
        print(
            f"  [ITM/{lang_label}] {len(unmatched_ids)} item(s) had a recognized str.*itm#<id> "
            f"reference with no name-table match and fell back to their slot name, "
            f"e.g.: {sample}{more}"
        )

    if unparsed_encoded:
        sample = ', '.join(unparsed_encoded[:5])
        more = f" (+{len(unparsed_encoded) - 5} more)" if len(unparsed_encoded) > 5 else ""
        print(
            f"  [ITM/{lang_label}] {len(unparsed_encoded)} item(s) had an itmNameEncoded value "
            f"that looked like a string-table reference but didn't match the expected pattern - "
            f"fell back to slot name instead of leaking raw text, e.g.: {sample}{more}"
        )

    print(f"[ITM/{lang_label}] Resolved {len(rows)} row(s) "
          f"({len(unmatched_ids)} unmatched, {len(unparsed_encoded)} unparsed)")
    return rows


# ---------------------------------------------------------------------------
# .stb binary parser - see the big comment block above the Armor Items
# pipeline section for the reverse-engineered file format.
# ---------------------------------------------------------------------------
STB_RECORD_SIZE = 26
STB_RECORDS_START = 7
STB_TYPE_NAME = 0x141  # base/masculine display name - the one we want


def parse_itm_stb(path):
    """Parse a raw str.itm.stb file (downloaded via swtor.jedipedia.net's
    /reader tool's "Original" link) into {numeric_id_str: name} - the exact
    same shape as ITMNameValues.json, entirely in memory, nothing written to
    disk. Returns (mapping, stats) where stats reports how many records were
    found/used, for a one-line log summary in the caller. Raises ValueError
    if the file doesn't look like a valid .stb (too small / truncated)."""
    with open(path, "rb") as f:
        data = f.read()

    if len(data) < STB_RECORDS_START + 4:
        raise ValueError(f"{path}: file too small to be a valid .stb file")

    count = struct.unpack_from("<I", data, 3)[0]
    expected_min_size = STB_RECORDS_START + count * STB_RECORD_SIZE
    if len(data) < expected_min_size:
        raise ValueError(
            f"{path}: file is smaller ({len(data)} bytes) than its own header "
            f"claims ({count} records needing at least {expected_min_size} bytes) "
            f"- likely truncated, or not a str.itm.stb file"
        )

    mapping = {}
    for i in range(count):
        offset = STB_RECORDS_START + i * STB_RECORD_SIZE
        record = data[offset:offset + STB_RECORD_SIZE]
        type_val = struct.unpack_from("<I", record, 8)[0]
        if type_val != STB_TYPE_NAME:
            continue
        length = struct.unpack_from("<H", record, 14)[0]
        if length == 0:
            continue
        full_id = struct.unpack_from("<Q", record, 0)[0]
        text_offset = struct.unpack_from("<I", record, 18)[0]
        text = data[text_offset:text_offset + length].decode("utf-8", errors="replace")
        mapping[str(full_id)] = text

    stats = {"total_records": count, "names_extracted": len(mapping)}
    return mapping, stats


def detect_lang_code(file_path):
    stem = os.path.splitext(os.path.basename(file_path))[0].lower()
    tokens = re.split(r"[^a-zà-ÿ]+", stem)
    for token in tokens:
        if token in LANG_STB_ALIASES:
            return LANG_STB_ALIASES[token]
    return None


def discover_lang_stb_files(raw_langs_dir):
    """Scans raw_langs_dir for *.stb files and maps each to a detected
    language code (fr, gr, ...). Returns {lang_code: file_path}. If more
    than one file maps to the same code, the last one found wins (with a
    warning) - shouldn't normally happen with one file per language."""
    found = {}
    unrecognized = []
    if not os.path.isdir(raw_langs_dir):
        return found, unrecognized
    for path in sorted(glob.glob(os.path.join(raw_langs_dir, "*.stb"))):
        code = detect_lang_code(path)
        if code is None:
            unrecognized.append(path)
            continue
        if code in found:
            print(f"Warning: both '{os.path.basename(found[code])}' and "
                  f"'{os.path.basename(path)}' in {RAW_LANGS_DIRNAME}/ map to language "
                  f"code '{code}' - using '{os.path.basename(path)}'")
        found[code] = path
    return found, unrecognized


def create_name_mapping(itm_rows):
    """
    Build an FQN -> in-game-name mapping from the in-memory ITM rows
    ([icon_value, slot, display_name]). Adds singular/plural variants and
    BASE_PATH_MAPPING-based shortened-path variants, same as the original
    1_CreateNameFile.py.
    """
    mapping = {}

    for row in itm_rows:
        if len(row) < 3:
            continue

        node_id = row[0]
        english_name = row[2]
        mapping[node_id] = english_name

        # Singular/plural variants
        if node_id.endswith('s'):
            mapping[node_id[:-1]] = english_name
        else:
            mapping[node_id + 's'] = english_name

        # Shortened base-path variants
        for short_path, full_path in BASE_PATH_MAPPING.items():
            if node_id.startswith(full_path):
                slot = node_id.split('.')[-1]
                shortened_id = f"{short_path}.{slot}"
                mapping[shortened_id] = english_name
                if shortened_id.endswith('s'):
                    mapping[shortened_id[:-1]] = english_name
                else:
                    mapping[shortened_id + 's'] = english_name

    return mapping


def combine_and_sort(ipp_rows, itm_rows, sort_column_index=SORT_COLUMN_INDEX):
    """
    Replace column 2 of every IPP row with the in-game name looked up from
    the ITM rows (bracketing the FQN when no match exists), and sort by
    sort_column_index. Returns the final row list - no unsorted
    intermediate, no separate "_sorted" file.
    """
    name_mapping = create_name_mapping(itm_rows)

    rows = []
    unmatched = 0
    for row in ipp_rows:
        row = list(row)
        if len(row) >= 6:
            node_id = row[0]
            if node_id in name_mapping:
                row[1] = name_mapping[node_id]
            else:
                row[1] = f"[{node_id}]"
                unmatched += 1
        rows.append(row)

    rows.sort(key=lambda r: r[sort_column_index] if len(r) > sort_column_index else '')

    print(
        f"[Combine] Combined {len(rows)} row(s), sorted by column {sort_column_index} "
        f"({unmatched} FQN(s) had no name match)"
    )
    return rows


def write_named_armor_csv(ipp_rows, raw_itm_rows, item_names, lang_label, output_path):
    """Resolves ITM display names for one language, combines with the shared
    IPP data, sorts, and writes ippArmorValues_<lang_label>.csv. Shared by
    the English path and every Raw_Langs/*.stb language."""
    if item_names is None:
        print(f"[{lang_label}] No name table available - skipping {os.path.basename(output_path)}")
        return
    itm_rows = resolve_itm_names(raw_itm_rows, item_names, lang_label)
    final_rows = combine_and_sort(ipp_rows, itm_rows)
    write_csv(output_path, final_rows)
    print(f"[Combine/{lang_label}] Wrote {len(final_rows)} row(s) to {output_path}")


def run_items_pipeline(script_dir, fields_mapping, armor_ipp_root):
    print("\n=== Armor Items (IPP/ITM) ===")

    raw_ipp_dir = os.path.join(script_dir, "Raw_IPP")
    raw_itm_dir = os.path.join(script_dir, "Raw_ITM")
    raw_langs_dir = os.path.join(script_dir, RAW_LANGS_DIRNAME)
    item_names_path = os.path.join(script_dir, ITM_NAMES_FILENAME)

    item_names_en = None
    if os.path.isfile(item_names_path):
        item_names_en = load_mapping_file(item_names_path)
        print(f"Loaded {len(item_names_en)} entries from {ITM_NAMES_FILENAME}")
    else:
        print(f"Warning: {ITM_NAMES_FILENAME} not found at {item_names_path} - English ITM names won't resolve")

    ipp_rows = process_ipp_files(raw_ipp_dir, fields_mapping)
    raw_itm_rows = process_itm_files_raw(raw_itm_dir, fields_mapping)

    if ipp_rows is not None:
        base_path = os.path.join(armor_ipp_root, ITEMS_BASE_OUTPUT_FILENAME)
        write_csv(base_path, ipp_rows)
        print(f"[IPP] Wrote {len(ipp_rows)} row(s) to {base_path}")

    if ipp_rows is None or raw_itm_rows is None:
        print("[Combine] Skipping - need both IPP and ITM data to build any named ArmorIPP file")
        return

    # English - unchanged from before, always attempted if ITMNameValues.json exists.
    en_output_path = os.path.join(armor_ipp_root, ITEMS_OUTPUT_FILENAME)
    write_named_armor_csv(ipp_rows, raw_itm_rows, item_names_en, "en", en_output_path)

    # Additional languages - one ippArmorValues_<code>.csv per file found in
    # Raw_Langs/. Optional: if the folder doesn't exist or is empty, this is
    # a silent no-op (same "optional folder" behavior as every other Raw_*
    # folder in this script).
    lang_files, unrecognized = discover_lang_stb_files(raw_langs_dir)
    if unrecognized:
        print(
            f"Warning: couldn't tell what language these file(s) are - name them like "
            f"ITMNameValues_French.stb / ITMNameValues_German.stb (or just include "
            f"french/fr or german/gr in the filename) - skipping: "
            + ", ".join(os.path.basename(p) for p in unrecognized)
        )
    if not lang_files:
        print(f"No additional-language .stb files found in {raw_langs_dir}/ - "
              f"only ippArmorValues_en.csv will be produced")
        return

    for code in sorted(lang_files):
        stb_path = lang_files[code]
        print(f"\n--- Language: {code} ({os.path.basename(stb_path)}) ---")
        try:
            item_names_lang, stats = parse_itm_stb(stb_path)
        except (ValueError, OSError) as e:
            print(f"  Error parsing {stb_path}: {e} - skipping {code}")
            continue
        print(f"  Parsed {stats['total_records']} raw record(s), "
              f"{stats['names_extracted']} usable name(s)")
        lang_output_path = os.path.join(armor_ipp_root, f"ippArmorValues_{code}.csv")
        write_named_armor_csv(ipp_rows, raw_itm_rows, item_names_lang, code, lang_output_path)


# =============================================================================
# Dye Colors pipeline (was ProcessDye.py)
#
# Reads:
#     itmAppearanceColorsPrototype.json  (raw node JSON, same folder as script)
#     ColorNameValues.json               (color name string-ID -> text dictionary,
#                                          same folder as script, from colornames.stb)
# Writes:
#     Dyes/DyeColors.csv
#
# Uses the same GOM.fields.json mapping already loaded for the other
# pipelines - inverted into a name -> id lookup, since this pipeline needs
# to find field IDs by their known names rather than translate IDs to names.
# =============================================================================

DYE_DEFS_FILENAME = "itmAppearanceColorsPrototype.json"
DYE_NAMES_FILENAME = "ColorNameValues.json"
DYE_OUTPUT_FILENAME = "DyeColors.csv"


def build_name_to_id_map(fields_mapping):
    """Invert the id -> name GOM.fields.json mapping into name -> id (string
    ids), so the Dye pipeline can look up a field's numeric ID by its known
    name."""
    name_to_id = {}
    for key, value in fields_mapping.items():
        if isinstance(value, str):
            name_to_id.setdefault(value, str(key))
    return name_to_id


def run_dye_pipeline(script_dir, fields_mapping, dyes_root):
    print("\n=== Dye Colors ===")

    defs_path = os.path.join(script_dir, DYE_DEFS_FILENAME)
    names_path = os.path.join(script_dir, DYE_NAMES_FILENAME)

    missing = [p for p in (defs_path, names_path) if not os.path.isfile(p)]
    if missing:
        for p in missing:
            print(f"Warning: {os.path.basename(p)} not found at {p}")
        print("Skipping Dye Colors pipeline")
        return

    name_to_id = build_name_to_id_map(fields_mapping)

    def fid(field_name):
        value = name_to_id.get(field_name)
        if value is None:
            raise KeyError(field_name)
        return value

    # Resolve the numeric field IDs we need by their real names, instead of
    # hardcoding opaque numbers. If the game's internal field IDs ever
    # change, this still works as long as GOM.fields.json is up to date.
    try:
        f_display_string = fid("itmAppColorDisplayString")   # -> string ID, resolved via ColorNameValues.json
        f_armor_scheme = fid("itmAppColorDefArmorScheme")    # -> the dye's color scheme ID
        f_defs_array = fid("itmAppColorsDefs")               # -> array of color scheme records
    except KeyError as e:
        print(
            f"Warning: field {e} not found in GOM.fields.json - skipping Dye Colors pipeline "
            f"(the game schema may have changed, or this isn't the right fields file)"
        )
        return

    print(f"Loading {DYE_NAMES_FILENAME}...")
    name_values = load_mapping_file(names_path)
    print(f"  {len(name_values)} localized strings loaded")

    print(f"Loading {DYE_DEFS_FILENAME}...")
    data = load_json_file(defs_path)

    defs = data.get(f_defs_array, [])
    print(f"  {len(defs)} color scheme entries found")

    processed = []
    seen_scheme_ids = {}
    skipped_no_scheme = 0
    skipped_no_name = 0

    # The "Dye number" is simply the 1-based position of each entry in the
    # itmAppColorsDefs list - the same row number you'd see browsing this
    # node on Jedipedia, and the same number the old raw-CSV workflow
    # captured as the leading "separator" value.
    for dye_number, entry in enumerate(defs, start=1):
        scheme_id = entry.get(f_armor_scheme)
        display_id = entry.get(f_display_string)

        if not scheme_id:
            skipped_no_scheme += 1
            continue

        name = name_values.get(str(display_id)) if display_id else None
        if not name:
            skipped_no_name += 1
            continue

        # colornames.stb uses a hyphen for combo names (e.g. "Black-White");
        # convert to the slash format used by the old DyeColors.csv / Blender
        # plugin (e.g. "Black/White"). Names without a hyphen (single/unique
        # color names) pass through unchanged. A few source strings also
        # have stray trailing whitespace/newlines - strip those.
        name = name.replace("-", "/").strip()

        processed.append([dye_number, scheme_id, name])
        seen_scheme_ids[scheme_id] = seen_scheme_ids.get(scheme_id, 0) + 1

    dupe_schemes = {sid: count for sid, count in seen_scheme_ids.items() if count > 1}

    print(f"Processed {len(processed)} valid dye entries")
    print(
        f"Skipped: {skipped_no_scheme} (no scheme id), "
        f"{skipped_no_name} (unresolved display name)"
    )
    if dupe_schemes:
        print(
            f"Note: {len(dupe_schemes)} scheme ID(s) produced more than one row "
            f"(same dye scheme referenced by multiple color instances)."
        )

    if not processed:
        print(f"No dye rows produced - {DYE_OUTPUT_FILENAME} not written")
        return

    # Sort alphabetically by dye name, same as the old script
    processed.sort(key=lambda row: row[2])

    # Space-delimited output, matching the old plugin's expected
    # DyeColors.csv format
    output_path = os.path.join(dyes_root, DYE_OUTPUT_FILENAME)
    with open(output_path, "w", encoding="utf-8") as f:
        for row in processed:
            f.write(f"{row[0]} {row[1]} {row[2]}\n")

    print(f"Saved {len(processed)} row(s) to {output_path}")


# =============================================================================
# Function Rename (guide step 7.0 - was the standalone FunctionNameReplace.py
# tool, folded directly into this script instead of being generated as a
# separate file)
#
# Reads the source __init__.py from script_dir (the same "Raw_" folder level
# as GOM.fields.json etc. - the dev copy you're actively editing), copies it
# into version_folder (also as __init__.py - that's what Blender needs to
# see), then renames names in that copy in place. ExtractedNames.txt is
# written back to script_dir. Reuses the version_input/normalized version
# already entered at the top of this run's main() - no second version prompt.
# =============================================================================

def _scene_prop_name(target):
    """
    If `target` is the assignment target of a bpy.types.Scene.<prop> = ...
    statement, return <prop>. Otherwise return None. Shared by the
    module-top-level scan and the register()/unregister()-body scan below.
    """
    if (isinstance(target, ast.Attribute) and
            isinstance(target.value, ast.Attribute) and
            isinstance(target.value.value, ast.Attribute) and
            isinstance(target.value.value.value, ast.Name)):
        if (target.value.value.value.id == 'bpy' and
                target.value.value.attr == 'types' and
                target.value.attr == 'Scene'):
            return target.attr
    return None


def extract_names_from_ast(file_path):
    """
    Extract function names, class names, global variable assignments,
    bl_idname string values, and bpy.types.Scene property assignments from a
    Python file using AST parsing. This is much more reliable than manual
    lists.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        print(f"Syntax error in Python file: {e}")
        return None

    names = {
        'functions': set(),
        'classes': set(),
        'global_vars': set(),
        'bpy_props': set(),   # bpy.types.Scene.<prop> assignments, wherever found
        'bl_idnames': set(),  # bl_idname string values found on Operator/Panel/Menu classes
    }

    class NameExtractor(ast.NodeVisitor):
        def __init__(self):
            self.in_class = False
            self.in_function = False

        def visit_FunctionDef(self, node):
            # Only add top-level function names (not methods or nested functions)
            blender_required_functions = ['register', 'unregister']
            if not self.in_class and not self.in_function and not node.name.startswith('_') and node.name not in blender_required_functions:
                names['functions'].add(node.name)

            # register()/unregister() commonly define bpy.types.Scene
            # properties in their body - scan for those specifically, even
            # though we otherwise skip visiting inside functions.
            if not self.in_class and not self.in_function and node.name in blender_required_functions:
                self._scan_for_scene_props(node)

            # Don't visit inside functions - we don't want to rename anything inside them
            old_in_function = self.in_function
            self.in_function = True
            # Skip visiting children - don't rename anything inside functions
            self.in_function = old_in_function

        def visit_AsyncFunctionDef(self, node):
            # Handle async functions the same way
            blender_required_functions = ['register', 'unregister']
            if not self.in_class and not self.in_function and not node.name.startswith('_') and node.name not in blender_required_functions:
                names['functions'].add(node.name)

            if not self.in_class and not self.in_function and node.name in blender_required_functions:
                self._scan_for_scene_props(node)

            # Don't visit inside functions
            old_in_function = self.in_function
            self.in_function = True
            # Skip visiting children
            self.in_function = old_in_function

        def visit_ClassDef(self, node):
            # Only add top-level class names
            if not self.in_class and not self.in_function:
                names['classes'].add(node.name)
                self._scan_for_bl_idname(node)

            # Don't visit inside classes - we don't want to rename anything inside them
            old_in_class = self.in_class
            self.in_class = True
            # Skip visiting children - don't rename anything inside classes
            self.in_class = old_in_class

        def visit_Assign(self, node):
            # Only handle top-level global variable assignments
            if not self.in_class and not self.in_function:
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        # Skip private variables, constants, and Blender-specific variables
                        excluded_vars = ['__version__', '__author__', '__email__', 'bl_info', 'bl_idname', 'bl_label', 'bl_description', 'bl_options']
                        if not target.id.startswith('_') and target.id not in excluded_vars:
                            names['global_vars'].add(target.id)
                    elif isinstance(target, ast.Attribute):
                        # Handle bpy.types.Scene.property_name assignments
                        # written directly at module scope
                        prop_name = _scene_prop_name(target)
                        if prop_name:
                            names['bpy_props'].add(f'bpy.types.Scene.{prop_name}')

            # Don't visit children if we're inside a class or function
            if not self.in_class and not self.in_function:
                self.generic_visit(node)

        def _scan_for_bl_idname(self, class_node):
            """
            Look at this class's own direct body (not nested defs) for a
            bl_idname = "..." assignment. Blender registers and invokes
            Operators/Panels/Menus by this string (e.g. bpy.ops.<bl_idname>
            for Operators), not by the Python class name - so it needs to be
            versioned too, or two renamed copies of the same class would
            still collide at registration time.
            """
            for stmt in class_node.body:
                targets = None
                value_node = None
                if isinstance(stmt, ast.Assign):
                    targets = stmt.targets
                    value_node = stmt.value
                elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
                    targets = [stmt.target]
                    value_node = stmt.value

                if not targets:
                    continue

                for target in targets:
                    if isinstance(target, ast.Name) and target.id == 'bl_idname':
                        if isinstance(value_node, ast.Constant) and isinstance(value_node.value, str):
                            names['bl_idnames'].add(value_node.value)

        def _scan_for_scene_props(self, func_node):
            """
            register()/unregister() bodies commonly contain
            bpy.types.Scene.<prop> = bpy.props.XProperty(...) statements -
            the standard place Blender addons put them. These are invisible
            to visit_Assign because it only looks at true module-top-level
            statements. Walk this function's own statements (any nesting -
            e.g. inside an `if`) to find them.
            """
            for stmt in ast.walk(func_node):
                if isinstance(stmt, ast.Assign):
                    for target in stmt.targets:
                        prop_name = _scene_prop_name(target)
                        if prop_name:
                            names['bpy_props'].add(f'bpy.types.Scene.{prop_name}')

    extractor = NameExtractor()
    extractor.visit(tree)

    return names


def create_replacements(names, version_input, normalized_version):
    """
    Create replacement pairs from extracted names.
    Uses longest-first sorting and word boundaries to prevent substring issues.
    """
    replacements = []

    # Collect all names into a single list for proper sorting
    all_items = []

    # Add functions and classes
    for name in names['functions'] | names['classes']:
        all_items.append(('identifier', name))

    # Add global variables
    for name in names['global_vars']:
        all_items.append(('identifier', name))

    # Add bl_idname string values (e.g. "object.my_op") - versioned the same
    # way as identifiers (suffix appended to the whole string), which also
    # naturally fixes up any bpy.ops.<bl_idname>(...) call sites, since
    # those contain the identical substring.
    for name in names['bl_idnames']:
        all_items.append(('bl_idname', name))

    # Add bpy properties (handle separately due to special syntax)
    bpy_replacements = []
    for prop_name in names['bpy_props']:
        prop_only = prop_name.split('.')[-1]
        new_prop_name = f"{prop_only}_{normalized_version}"
        new_full_name = f"bpy.types.Scene.{new_prop_name}"
        bpy_replacements.append((prop_name, new_full_name))
        bpy_replacements.append((prop_only, new_prop_name))

    # Sort bpy properties by length (longest first)
    bpy_replacements.sort(key=lambda x: len(x[0]), reverse=True)

    # Sort regular identifiers (and bl_idname strings) by length (longest
    # first) to prevent substring conflicts across ALL renamed categories at
    # once - e.g. so a bl_idname isn't partially re-matched by a shorter
    # function name sharing a substring, or vice versa.
    all_items.sort(key=lambda x: len(x[1]), reverse=True)

    all_names = []  # For display purposes

    # Process regular identifiers + bl_idname strings
    for item_type, name in all_items:
        new_name = f"{name}_{normalized_version}"
        replacements.append((name, new_name))
        all_names.append((name, new_name))

    # Add bpy properties
    for old_name, new_name in bpy_replacements:
        replacements.append((old_name, new_name))
        all_names.append((old_name, new_name))

    # Hardcoded replacements that account for versioned variable names
    hardcoded_replacements = [
        (r'"name":\s*"JC SWTOR Tools \([^)]+\)"', f'"name": "JC SWTOR Tools ({version_input})"'),
        # Match the versioned variable name and update the string value
        (r'GAME_VERSION[^=]*=\s*"[^"]*"', f'GAME_VERSION_{normalized_version} = "{version_input}"')
    ]

    return replacements, hardcoded_replacements, all_names


def replace_in_file(file_path, replacements):
    """
    Perform find and replace operations in the specified file using word boundaries for function names
    and regex patterns for hardcoded replacements.
    """
    try:
        # Read the original file
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()

        # Perform replacements
        modified_content = content
        replacements_made = 0

        for old_item, new_item in replacements:
            # Check if this is a regex pattern (contains regex characters)
            regex_chars = ['(', ')', '[', ']', '*', '+', '?', '\\', '^', '$']
            if any(char in old_item for char in regex_chars):
                # This is a regex pattern - use regex substitution
                matches = re.findall(old_item, modified_content)
                count = len(matches)

                if count > 0:
                    modified_content = re.sub(old_item, new_item, modified_content)
                    replacements_made += count
                    print(f"  Replaced pattern '{old_item}' with '{new_item}' ({count} occurrences)")
            else:
                # This is a function/class/variable/bl_idname - use word boundaries
                pattern = r'\b' + re.escape(old_item) + r'\b'
                matches = re.findall(pattern, modified_content)
                count = len(matches)

                if count > 0:
                    modified_content = re.sub(pattern, new_item, modified_content)
                    replacements_made += count
                    print(f"  Replaced '{old_item}' with '{new_item}' ({count} occurrences)")

        # Write the modified content back to the file
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(modified_content)

        return replacements_made

    except FileNotFoundError:
        print(f"Error: Python file '{file_path}' not found.")
        return 0
    except Exception as e:
        print(f"Error processing file: {e}")
        return 0


def save_extracted_names(names, output_file):
    """
    Save the extracted names to a file for review.
    """
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("=== EXTRACTED NAMES ===\n\n")

            f.write("FUNCTIONS:\n")
            for name in sorted(names['functions']):
                f.write(f"{name}\n")

            f.write(f"\nCLASSES:\n")
            for name in sorted(names['classes']):
                f.write(f"{name}\n")

            f.write(f"\nGLOBAL VARIABLES:\n")
            for name in sorted(names['global_vars']):
                f.write(f"{name}\n")

            f.write(f"\nBL_IDNAME VALUES:\n")
            for name in sorted(names['bl_idnames']):
                f.write(f"{name}\n")

            f.write(f"\nBPY PROPERTIES:\n")
            for name in sorted(names['bpy_props']):
                f.write(f"{name}\n")

        print(f"Extracted names saved to: {output_file}")
    except Exception as e:
        print(f"Warning: Could not save extracted names: {e}")


def prepare_function_rename(script_dir, version_input, normalized_version, version_folder):
    """
    Guide step 7.0, part 1 (preview - no prompts, no side effects on
    version_folder). The plugin source lives as __init__.py right next to
    this script (the "Raw_" folder level) - the dev copy you're actively
    editing. This reads it, extracts names via AST, and builds the
    replacement list, printing a preview so the y/n confirmation can be
    gathered up front with the rest of the run's prompts, before any of
    the data-generation pipelines run.

    The actual copy-into-version_folder + replace happens later, in
    apply_function_rename(), once version_folder exists and all prompts
    are already answered.

    Returns a dict of everything apply_function_rename() needs, or None if
    this step can't run (no source __init__.py, or it failed to parse) -
    in which case main() should skip asking for confirmation altogether.
    """
    print("\n=== Function Rename (preview) ===")

    source_init_path = os.path.join(script_dir, "__init__.py")
    if not os.path.isfile(source_init_path):
        print(f"Warning: __init__.py not found at {source_init_path} - skipping Function Rename")
        return None

    print(f"Source plugin file found: {source_init_path}")

    print("\nExtracting names from __init__.py using AST parsing...")
    names = extract_names_from_ast(source_init_path)
    if names is None:
        print("Skipping Function Rename - failed to parse __init__.py")
        return None

    extracted_names_path = os.path.join(script_dir, "ExtractedNames.txt")
    save_extracted_names(names, extracted_names_path)

    total_names = (len(names['functions']) + len(names['classes']) + len(names['global_vars'])
                   + len(names['bpy_props']) + len(names['bl_idnames']))
    print(f"\nExtracted {total_names} names:")
    print(f"  Functions: {len(names['functions'])}")
    print(f"  Classes: {len(names['classes'])}")
    print(f"  Global Variables: {len(names['global_vars'])}")
    print(f"  Bl_idname values: {len(names['bl_idnames'])}")
    print(f"  Bpy Properties: {len(names['bpy_props'])}")

    replacements, hardcoded_replacements, all_names = create_replacements(names, version_input, normalized_version)

    print(f"\nSample replacements (showing longest first to prevent substring conflicts):")
    for old_name, new_name in all_names[:15]:
        print(f"  {old_name} -> {new_name}")
    if len(all_names) > 15:
        print(f"  ... and {len(all_names) - 15} more")

    print(f"\nHardcoded replacements:")
    for pattern, replacement in hardcoded_replacements:
        print(f"  {pattern} -> {replacement}")

    all_replacements = replacements + hardcoded_replacements

    dest_init_path = os.path.join(version_folder, "__init__.py")
    print(f"\nReady to copy __init__.py into {version_folder} and apply {len(all_replacements)} replacements")
    if os.path.exists(dest_init_path):
        print(f"WARNING: '__init__.py' already exists in {version_folder} and will be overwritten!")

    return {
        "source_init_path": source_init_path,
        "dest_init_path": dest_init_path,
        "all_replacements": all_replacements,
        "extracted_names_path": extracted_names_path,
    }


def apply_function_rename(plan):
    """
    Guide step 7.0, part 2 (the actual work). Copies the source __init__.py
    into version_folder and applies the replacements computed earlier by
    prepare_function_rename(), leaving the source __init__.py untouched.
    Only called once the user has already confirmed (that prompt happens
    up front in main(), alongside all the other input() calls).
    """
    source_init_path = plan["source_init_path"]
    dest_init_path = plan["dest_init_path"]
    all_replacements = plan["all_replacements"]
    extracted_names_path = plan["extracted_names_path"]

    print("\n=== Function Rename ===")

    try:
        with open(source_init_path, 'r', encoding='utf-8') as original:
            with open(dest_init_path, 'w', encoding='utf-8') as new_file:
                new_file.write(original.read())
        print(f"Copied to: {dest_init_path}")
    except Exception as e:
        print(f"Error copying file: {e}")
        return

    print("\nPerforming replacements...")
    total_replacements = replace_in_file(dest_init_path, all_replacements)

    if total_replacements > 0:
        print(f"\nSuccess! Made {total_replacements} total replacements in '{dest_init_path}'")
        print(f"Source file '{source_init_path}' remains unchanged.")
    else:
        print(f"\nNo replacements were made in '{dest_init_path}'")

    print(f"Check '{extracted_names_path}' to review what names were found and processed.")


# =============================================================================
# Entry point
# =============================================================================

def sanitize_folder_name(name):
    """Strip characters that aren't valid in Windows folder names."""
    return re.sub(r'[<>:"/\\|?*]', '_', name).strip()


def normalize_version(version_input):
    """
    Convert version input to normalized format (remove dots).
    Examples: "7.7" -> "77", "7.5.1" -> "751", "77" -> "77"

    Matches the normalization the Function Rename step (below) uses for its
    own version suffixes, so the version-folder name and the plugin's
    versioned identifiers stay consistent - both "77", not
    "jc_swtor_tools_7.7" next to identifiers suffixed "_77". Also reused
    directly as the Function Rename step's normalized_version, since both
    now run within the same script invocation.
    """
    return version_input.replace('.', '')


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))

    print("=== SWTOR Plugin Data Generator - Setup ===")
    print("Answer everything below up front; the rest of the run happens without further prompts.\n")

    # =========================================================================
    # 1. Gather ALL user input first - no processing happens until every
    #    prompt below is answered, so a run doesn't die on a bad path input
    #    halfway through several minutes of data generation.
    # =========================================================================

    # ---- Game version ----
    version_input = ""
    while not version_input:
        version_input = input("Game version? (e.g. 7.7 or 791a): ").strip()
        if not version_input:
            print("Please enter a game version.")

    version = sanitize_folder_name(normalize_version(version_input))
    if not version:
        print("Error: nothing usable left in the version after normalizing - please rerun with a different value.")
        return
    print(f"Normalized version: {version}")

    # ---- Resources folder (face index.xml path gets derived from this) ----
    head_race_dir = get_head_race_directory()

    version_folder = os.path.join(script_dir, f"jc_swtor_tools_{version}")

    # ---- Function Rename preview + confirm ----
    rename_plan = prepare_function_rename(script_dir, version_input, version, version_folder)
    rename_confirm = False
    if rename_plan is not None:
        confirm = input("\nDo you want to proceed with the Function Rename step? (y/N): ").strip().lower()
        rename_confirm = confirm in ('y', 'yes')
        if not rename_confirm:
            print("Function Rename step will be skipped.")

    print("\n=== All inputs collected - starting processing (no more prompts) ===")

    # =========================================================================
    # 2. Processing. Nothing below this point calls input().
    # =========================================================================

    char_root = os.path.join(version_folder, "Char")
    dyes_root = os.path.join(version_folder, "Dyes")
    armor_ipp_root = os.path.join(version_folder, "ArmorIPP")
    anim_root = os.path.join(version_folder, "Anim")
    blends_root = os.path.join(version_folder, "Blends")
    os.makedirs(char_root, exist_ok=True)
    os.makedirs(dyes_root, exist_ok=True)
    os.makedirs(armor_ipp_root, exist_ok=True)
    os.makedirs(anim_root, exist_ok=True)
    os.makedirs(blends_root, exist_ok=True)
    print(f"\nWriting output to: {version_folder}")

    mapping_path = os.path.join(script_dir, "GOM.fields.json")
    print(f"\nLoading {mapping_path}...")
    fields_mapping = load_mapping_file(mapping_path)
    print(f"Successfully loaded {len(fields_mapping)} field mapping entries")

    run_pcs_pipeline(script_dir, fields_mapping, char_root)
    run_color_pipeline(script_dir, fields_mapping, char_root)
    write_head_races_csv(head_race_dir, char_root)
    write_constant_char_files(char_root)
    run_items_pipeline(script_dir, fields_mapping, armor_ipp_root)
    run_dye_pipeline(script_dir, fields_mapping, dyes_root)

    if rename_confirm:
        apply_function_rename(rename_plan)

    print(f"\nDone. Everything was written under: {version_folder}")


if __name__ == "__main__":
    main()