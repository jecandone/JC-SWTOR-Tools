#!/usr/bin/env python3
"""
Creates a set of "Raw_*" folders in the same directory as this script.
"""

import os

FOLDER_NAMES = [
    "Raw_EyeColor",
    "Raw_HairColor",
    "Raw_IPP",
    "Raw_ITM",
    "Raw_PCS",
    "Raw_SkinColor",
    "Raw_Langs",
]


def main():
    # Directory where this script is located
    base_dir = os.path.dirname(os.path.abspath(__file__))

    for name in FOLDER_NAMES:
        folder_path = os.path.join(base_dir, name)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            print(f"Created: {folder_path}")
        else:
            print(f"Already exists: {folder_path}")


if __name__ == "__main__":
    main()