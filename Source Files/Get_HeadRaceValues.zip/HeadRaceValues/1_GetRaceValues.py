import xml.etree.ElementTree as ET
import csv
import os

def get_directory_path():
    while True:
        directory_path = input("Please enter the path to the directory containing index.xml: ")
        if os.path.isdir(directory_path):
            return directory_path
        else:
            print("The specified path is not a directory. Please enter a valid directory path.")

# Prompt user for the directory path
directory_path = get_directory_path()

# Construct the XML file path
xml_file_path = os.path.join(directory_path, 'index.xml')

# Get the directory of the script for saving the CSV file
script_directory = os.path.dirname(os.path.abspath(__file__))
csv_file_path = os.path.join(script_directory, 'HeadRaces.csv')

try:
    # Parse the XML file
    tree = ET.parse(xml_file_path)
    root = tree.getroot()

    # Set to store unique race values
    unique_races = set()

    # Extract race values from XML
    for tag in root.findall('.//Tag[@name="Race"]'):
        race = tag.get('value')
        if race:
            unique_races.add(race)

    # Write unique race values to CSV
    with open(csv_file_path, mode='w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        for race in sorted(unique_races):
            writer.writerow([race])

    print(f"Unique races have been written to {csv_file_path}")

except FileNotFoundError:
    print("The file index.xml was not found in the specified directory.")
except PermissionError:
    print("Permission denied: Unable to read the XML file. Please check your file permissions.")
except Exception as e:
    print(f"An error occurred: {e}")
