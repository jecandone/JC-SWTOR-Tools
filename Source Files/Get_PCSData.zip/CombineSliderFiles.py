import os
import csv

# Get the current working directory
folder_path = os.getcwd()

# List to store rows from CSV files
rows = []

# Loop through files in the folder
for filename in os.listdir(folder_path):
    if filename.endswith('_sliders.csv'):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, 'r') as csvfile:
            csvreader = csv.reader(csvfile)
            for row in csvreader:
                rows.append(row)

# Sort rows alphabetically by columns
rows.sort(key=lambda x: (x[0], x[1], x[2]))

# Path to the new CSV file
output_file = os.path.join(folder_path, 'CharSliderLabels.csv')

# Write the sorted rows to the new CSV file
with open(output_file, 'w', newline='') as csvfile:
    csvwriter = csv.writer(csvfile)
    for row in rows:
        csvwriter.writerow(row)

print(f"Combined CSV file created at: {output_file}")
