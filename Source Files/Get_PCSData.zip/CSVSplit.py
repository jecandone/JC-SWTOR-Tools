import os
import csv
import re
from typing import List, Dict
import glob

def get_output_structure(input_path: str) -> tuple:
    """Extract directory structure from input filename."""
    # Get the base filename without '_raw.csv'
    base_name = os.path.basename(input_path).replace('_raw.csv', '')
    
    # Split by underscores
    parts = base_name.split('_')
    
    if len(parts) >= 3:
        string1 = parts[0]
        string2 = parts[1]
        string3 = parts[2]  # This will be used as a directory
        return string1, string2, string3
    else:
        # If filename doesn't match expected pattern, use default structure
        print(f"Warning: Filename {input_path} doesn't match expected pattern string1_string2_string3_raw.csv")
        return 'default', 'default', 'default'

def ensure_nested_directory(output_dir: str, string1: str, string2: str, string3: str) -> str:
    """Create nested directory structure and return the full path."""
    # Create first level directory
    first_level = os.path.join(output_dir, string1)
    if not os.path.exists(first_level):
        os.makedirs(first_level)
        
    # Create second level directory
    second_level = os.path.join(first_level, string2)
    if not os.path.exists(second_level):
        os.makedirs(second_level)
        
    # Create third level directory
    third_level = os.path.join(second_level, string3)
    if not os.path.exists(third_level):
        os.makedirs(third_level)
        
    return third_level

def ensure_output_directory():
    """Create the output directory if it doesn't exist."""
    output_dir = "output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    return output_dir

def read_raw_csv(file_path: str) -> str:
    """Read the raw CSV file and return its contents as a string."""
    with open(file_path, 'r') as file:
        return file.read()

def extract_document_content(raw_content: str) -> str:
    """Extract the content from within document_content tags."""
    start = raw_content.find("<document_content>") + len("<document_content>")
    end = raw_content.find("</document_content>")
    return raw_content[start:end].strip()

def get_section_content(content: str, section_name: str) -> List[str]:
    """Extract content for a specific section."""
    lines = content.split('\n')
    section_lines = []
    in_section = False
    
    for line in lines:
        if line.startswith(section_name):
            in_section = True
            continue  # Skip the section header line
        elif in_section:
            if any(line.startswith(other_section) for other_section in [
                'appPcsCustomizationSlots',
                'appPcsSliderMap',
                'appPcsHeadSkeletonMap',
                'appPcsSkeletonDisplayList',
                'appPcsCustomizationSlotNameIds',
                'appPcsSkeletonRandomWeights'
            ] if other_section != section_name):
                break
            if line.strip():  # Only append non-empty lines
                section_lines.append(line)
    
    return section_lines

def process_head_skeleton_map(content: str) -> List[List[str]]:
    """Process the appPcsHeadSkeletonMap section.
    - Handles either bfa/bfb/bfn/bfs or bma/bmb/bmn/bms rows
    - Extracts number from 'List of Int (X Rows)' format
    - Removes middle column for data rows
    """
    lines = get_section_content(content, 'appPcsHeadSkeletonMap')
    processed_lines = []
    current_header = None
    
    for line in lines:
        parts = line.split('\t')
        if not parts:
            continue
            
        first_col = parts[0].strip()
        
        # Check if this is a header line (bf* or bm* pattern)
        if any(first_col.startswith(prefix) for prefix in ['bfa', 'bfb', 'bfn', 'bfs', 'bma', 'bmb', 'bmn', 'bms']):
            current_header = first_col
            # Extract number from "List of Int (X Rows)"
            match = re.search(r'List of Int \((\d+) [Rr]ows\)', parts[1])
            if match:
                row_count = match.group(1)
                processed_lines.append([first_col, row_count])
        elif current_header and len(parts) >= 3:
            # Keep only first and last columns for data rows
            processed_lines.append([parts[0], parts[2]])
    
    return processed_lines

def process_customization_slots(content: str) -> Dict[str, List[List[str]]]:
    """Process the appPcsCustomizationSlots section."""
    lines = content.split('\n')
    sections = {}
    current_section = None
    current_content = []
    
    def is_3_4_digit_number(s: str) -> bool:
        """Check if string is a 3 or 4 digit number."""
        return s.isdigit() and 100 <= int(s) <= 9999

    def process_section_content(content: List[List[str]]) -> List[List[str]]:
        """Process section content by removing first row and middle column."""
        if len(content) <= 1:  # If only one row or empty, return empty list
            return []
        
        # Skip first row and process remaining rows
        processed = []
        for parts in content[1:]:  # Skip first row
            if len(parts) >= 3:  # Only process rows with at least 3 columns
                # Keep only first and last columns
                processed.append([parts[0], parts[-1]])
        return processed

    for line in lines:
        if 'onSlots' in line:  # Found start of section
            continue  # Skip the header line
        elif line.strip().startswith('appPcsSliderMap'):
            if current_section and current_content:
                sections[current_section] = process_section_content(current_content)
            break
            
        parts = line.split('\t')
        if parts and parts[0].strip():
            first_col = parts[0].strip()
            
            # Check if this is a new section start (3-4 digit number)
            if is_3_4_digit_number(first_col):
                # Save previous section if it exists
                if current_section and current_content:
                    sections[current_section] = process_section_content(current_content)
                # Start new section
                current_section = first_col
                current_content = [parts]
            elif current_section:  # We're in a section
                # Skip rows starting with 5+ digit numbers or containing ippGearFlourishByBodyType
                if not ('ippGearFlourishByBodyType' in line or 
                      (first_col.isdigit() and len(first_col) >= 5)):
                    current_content.append(parts)
    
    # Add the last section if it exists
    if current_section and current_content:
        sections[current_section] = process_section_content(current_content)
    
    # Remove any sections that ended up empty after processing
    sections = {k: v for k, v in sections.items() if v}
    
    return sections

def process_slider_map(content: str) -> Dict[str, List[List[str]]]:
    """Process the appPcsSliderMap section."""
    lines = get_section_content(content, 'appPcsSliderMap')
    sections = {}
    current_section = None
    current_content = []
    
    for line in lines:
        parts = line.split('\t')
        # Check if line starts with 3 or 4 digit number
        if re.match(r'^\d{3,4}$', parts[0]):
            if current_section:
                sections[current_section] = process_slider_section(current_content)
            current_section = parts[0]
            current_content = []  # Skip the first row
        elif current_section:
            current_content.append(parts)
    
    # Process the last section
    if current_section and current_content:
        sections[current_section] = process_slider_section(current_content)
    
    return sections

def process_slider_section(content: List[List[str]]) -> List[List[str]]:
    """Process individual slider section content."""
    processed_lines = []
    
    for parts in content:
        # Check if this is a header row (contains "List of Int")
        if any("List of Int" in part for part in parts):
            # Extract number from "List of Int (XX rows)"
            match = re.search(r'List of Int \((\d+) [Rr]ows\)', parts[1])
            if match:
                row_count = match.group(1)
                processed_lines.append([parts[0], row_count])
        else:
            # Data row - remove middle column
            if len(parts) >= 3:
                processed_lines.append([parts[0], parts[2]])
    
    return processed_lines

def process_skeleton_display_list(content: str) -> List[List[str]]:
    """Process the appPcsSkeletonDisplayList section."""
    lines = get_section_content(content, 'appPcsSkeletonDisplayList')
    return [line.split('\t') for line in lines if line.strip()]

def process_slot_name_ids(content: str) -> List[List[str]]:
    """Process the appPcsCustomizationSlotNameIds section."""
    lines = get_section_content(content, 'appPcsCustomizationSlotNameIds')
    
    # Filter out unwanted rows
    filtered_lines = []
    for line in lines:
        if line.startswith('appPcsSkeletonRandomWeights'):
            break
        filtered_lines.append(line)
    
    # Process the remaining lines
    processed_lines = []
    for i, line in enumerate(filtered_lines):
        parts = line.split('\t')
        if i == 0:  # Header row - keep as is
            processed_lines.append(parts)
        else:  # Data rows - remove middle column
            processed_lines.append([parts[0], parts[2]])
    
    return processed_lines

def write_section_to_file(data: List[List[str]], output_path: str):
    """Write processed section data to a new CSV file."""
    with open(output_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)

def process_file(input_path: str, output_dir: str):
    """Process a single raw CSV file and split it into sections."""
    # Get directory structure from filename
    string1, string2, string3 = get_output_structure(input_path)
    
    # Create nested directory structure
    final_output_dir = ensure_nested_directory(output_dir, string1, string2, string3)
    
    # Read and parse input file
    raw_content = read_raw_csv(input_path)
    content = extract_document_content(raw_content)
    
    # Process regular sections
    processing_functions = {
        'appPcsSkeletonDisplayList': process_skeleton_display_list,
        'appPcsCustomizationSlotNameIds': process_slot_name_ids,
        'appPcsHeadSkeletonMap': process_head_skeleton_map  # Added this back
    }
    
    for section_name, process_func in processing_functions.items():
        processed_data = process_func(content)
        if processed_data:
            output_path = os.path.join(final_output_dir, f"{section_name}.csv")
            write_section_to_file(processed_data, output_path)
            print(f"Created {os.path.basename(output_path)}")
    
    # Process slider map sections
    slider_sections = process_slider_map(content)
    for section_num, section_data in slider_sections.items():
        output_path = os.path.join(final_output_dir, f"sliderValues_{section_num}.csv")
        write_section_to_file(section_data, output_path)
        print(f"Created {os.path.basename(output_path)}")
    
    # Process customization slots sections
    custom_sections = process_customization_slots(content)
    for section_num, section_data in custom_sections.items():
        output_path = os.path.join(final_output_dir, f"SliderData_{section_num}.csv")
        write_section_to_file(section_data, output_path)
        print(f"Created {os.path.basename(output_path)}")

def main():
    """Main function to process all raw CSV files in the directory."""
    # Ensure output directory exists
    output_dir = ensure_output_directory()
    print(f"Created output directory: {output_dir}")
    
    # Find all CSV files ending with '_raw.csv'
    raw_files = glob.glob('*_raw.csv')
    
    if not raw_files:
        print("No '_raw.csv' files found in the current directory.")
        return
        
    for file_path in raw_files:
        print(f"\nProcessing {file_path}...")
        process_file(file_path, output_dir)
        print(f"Finished processing {file_path}")

if __name__ == "__main__":
    main()