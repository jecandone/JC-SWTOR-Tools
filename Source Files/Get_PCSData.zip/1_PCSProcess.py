import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import psutil
import time

def is_browser_running(browser_name):
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] and browser_name.lower() in proc.info['name'].lower():
            return True
    return False

def is_url_open(url):
    options = Options()
    options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    driver = webdriver.Chrome(service=Service('C:\\Users\\Jeff\\Desktop\\testDirect\\chromedriver-win64\\chromedriver.exe'), options=options)
    
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if driver.current_url == url:
            return driver
    return None

def map_values(class_value, gender_value, species_value):
    class_mapping = {
        "bounty_hunter": "BountyHunter",
        "imperial_agent": "ImperialAgent",
        "jedi_consular": "JediConsular",
        "jedi_knight": "JediKnight",
        "sith_inquisitor": "SithSorc",
        "sith_warrior": "SithWarrior",
        "smuggler": "Smuggler",
        "trooper": "Trooper"
    }
    gender_mapping = {
        "female": "f",
        "male": "m"
    }
    species_mapping = {
        "cathar": "Cathar",
        "chiss": "Chiss",
        "cyborg": "Cyborg",
        "human": "Human",
        "miralukan_legacy": "Miraluken",
        "mirialan_legacy": "Mirialan",
        "nautolan": "Nautolan",
        "rattataki": "Rattataki",
        "sith_legacy": "Sith",
        "togruta": "Togruta",
        "twilek_legacy": "Twilek",
        "zabrak": "Zabrak",
        "chiss_legacy": "Chiss",
        "cyborg_legacy": "Cyborg",
        "rattataki_legacy": "Rattataki"
    }

    species_value = species_value.split('_')[0]
    species_value = ''.join([i for i in species_value if not i.isdigit()]).capitalize()

    return class_mapping[class_value], gender_mapping[gender_value], species_value

def create_and_save_csv(selected_row, file_path, data):
    #output_file_path = os.path.join(os.path.dirname(file_path), 'output')
    output_file_path = os.path.join(os.path.dirname(file_path))
    os.makedirs(output_file_path, exist_ok=True)
    
    parts = selected_row.split(".")
    if len(parts) >= 4:
        class_value, gender_value, species_value = parts[1:4]
        class_mapped, gender_mapped, species_mapped = map_values(class_value, gender_value, species_value)
        
        # Remove "_legacy" suffix if present in the species tag
        if species_mapped.endswith("_legacy"):
            species_mapped = species_mapped[:-7]
        
        file_name = f"{class_mapped}_{gender_mapped}_{species_mapped}_raw.csv"
        full_path = os.path.join(output_file_path, file_name)
        
        with open(full_path, 'w', newline='') as csvfile:
            csvfile.write(data)
        
        print(f"CSV file created: {full_path}")
        return True
    return False


def main():
    url = "https://swtor.jedipedia.net/reader"
    browsers = ["chrome", "firefox", "msedge"]

    for browser in browsers:
        if is_browser_running(browser):
            driver = is_url_open(url)
            if driver:
                try:
                    # Simulate Ctrl+C to copy selected content
                    webdriver.ActionChains(driver).key_down(Keys.CONTROL).send_keys('c').key_up(Keys.CONTROL).perform()
                    
                    # Wait 1.5 seconds after copying
                    time.sleep(1.5)
                    
                    # Get the copied data from clipboard
                    import pyperclip
                    data = pyperclip.paste()
                    
                    if data:
                        # Get the first row that starts with "pcs"
                        first_row = next((line for line in data.splitlines() if line.startswith("pcs")), None)
                        if first_row:
                            print(f"Found first row: {first_row}")
                            success = create_and_save_csv(first_row, __file__, data)
                            if success:
                                print("Data successfully processed and saved")
                            else:
                                print("Error: Could not process the data")
                        else:
                            print("Error: No valid first row found in data")
                    else:
                        print("Error: No data in clipboard")
                except Exception as e:
                    print(f"Error: {str(e)}")
                finally:
                    driver.quit()
                break
    else:
        print("The specified URL is not open in any supported browser.")

if __name__ == "__main__":
    main()