import os
import csv
import re

def extract_filename_parts(filename):
    """Extract parts from filename according to specified pattern."""
    name_without_ext = os.path.splitext(filename)[0]
    parts = name_without_ext.split('_')
    
    base_name = parts[0]
    gender = parts[1].upper() if len(parts) > 1 else ''
    species = parts[2].capitalize() if len(parts) > 2 else ''
    
    return base_name, gender, species

def find_slot_info(lines, slot_name):
    """Find slot information in the customization slot section and slider map section."""
    # First find the display name in the customization slot section
    display_name = "n/a"
    for line in lines:
        parts = line.strip().split('\t')
        if len(parts) >= 3 and parts[0] == slot_name:
            display_name = parts[2]
            break
    
    # Look for row count in the file
    min_val = "0"
    max_val = "1"
    found_count = False
    
    for line in lines:
        if f'{slot_name}\tList of Int' in line:
            try:
                max_val = line.split('(')[1].split(' ')[0]  # Extract number between '(' and ' rows)'
                min_val = "1"  # If we find a valid row count, minimum is always 1
                found_count = True
                break
            except:
                # If parsing fails, keep defaults
                pass
    
    # If we didn't find a row count, return n/a for display name
    if not found_count:
        display_name = "n/a"
    
    return display_name, min_val, max_val

def find_skeleton_weights(lines):
    """Find min and max skeleton weight values."""
    skeleton_section = False
    numbers = []
    
    for line in lines:
        if 'appPcsSkeletonRandomWeights' in line:
            skeleton_section = True
            continue
        if skeleton_section:
            parts = line.strip().split('\t')
            if len(parts) >= 1 and parts[0].isdigit():
                numbers.append(int(parts[0]))
            else:
                break
    
    if numbers:
        return str(min(numbers)), str(max(numbers))
    return "1", "4"  # Default values

def find_head_values(lines, gender):
    """Find min and max values under 'bma' section for males or 'bfn' section for females."""
    section_identifier = 'bma' if gender == 'M' else 'bfn'
    numbers = []
    
    for i, line in enumerate(lines):
        if f'{section_identifier}\t' in line:  # Added tab to ensure exact match
            j = i + 1
            while j < len(lines):
                parts = lines[j].strip().split('\t')
                if len(parts) >= 1 and parts[0].isdigit():
                    numbers.append(int(parts[0]))
                    j += 1
                else:
                    break
    
    if numbers:
        return str(min(numbers)), str(max(numbers))
    return "1", "24"  # Default values

def create_sliders_row(input_file_path, lines):
    """Create a row for the sliders CSV file."""
    filename = os.path.basename(input_file_path)
    base_name, gender, species = extract_filename_parts(filename)
    
    # Get skeleton weights
    min_skeleton, max_skeleton = find_skeleton_weights(lines)
    
    # Get head values based on gender
    min_head, max_head = find_head_values(lines, gender)
    
    # Get slot information for various attributes
    scars_info = find_slot_info(lines, 'appSlotAge')
    complexion_info = find_slot_info(lines, 'appSlotComplexion')
    eye_color_info = find_slot_info(lines, 'appSlotEyeColor')
    face_paint_info = find_slot_info(lines, 'appSlotFacePaint')
    hair_info = find_slot_info(lines, 'appSlotHair')
    hair_color_info = find_slot_info(lines, 'appSlotHairColor')
    skin_color_info = find_slot_info(lines, 'appSlotSkinColor')
    face_hair_info = find_slot_info(lines, 'appSlotFaceHair')
    
    # Build the row
    row = [
        base_name, gender, species, "Body",
        min_skeleton, max_skeleton, "Head",
        min_head, max_head,
        scars_info[0], scars_info[1], scars_info[2],
        complexion_info[0], complexion_info[1], complexion_info[2],
        eye_color_info[0], eye_color_info[1], eye_color_info[2],  # No longer replacing spaces
        face_paint_info[0], face_paint_info[1], face_paint_info[2],
        hair_info[0], hair_info[1], hair_info[2],
        hair_color_info[0], hair_color_info[1], hair_color_info[2],
        skin_color_info[0], skin_color_info[1], skin_color_info[2],
        face_hair_info[0], face_hair_info[1], face_hair_info[2],
        "0", "5"
    ]
    
    return row

def process_csv_file(input_file_path):
    """Process a single CSV file and create both output files."""
    # Get the output file paths
    dir_name = os.path.dirname(input_file_path)
    file_name = os.path.basename(input_file_path)
    new_file_name = file_name.replace('_raw', '')
    sliders_file_name = file_name.replace('_raw', '_sliders')
    output_file_path = os.path.join(dir_name, new_file_name)
    sliders_file_path = os.path.join(dir_name, sliders_file_name)
    
    # Read the input file
    with open(input_file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    
    # Process main file (original functionality)
    start_index = 0
    for i, line in enumerate(lines):
        if 'ClassView' in line:
            start_index = i
            break
    
    end_index = len(lines)
    skeleton_section_found = False
    number_count = 0
    
    for i, line in enumerate(lines):
        if 'appPcsSkeletonRandomWeights' in line:
            skeleton_section_found = True
            continue
        if skeleton_section_found:
            parts = line.strip().split('\t')
            if parts[0].isdigit() and 1 <= int(parts[0]) <= 4:
                number_count += 1
                if number_count == 4:
                    end_index = i + 1
                    break
    
    # Write the processed main file
    processed_lines = lines[start_index:end_index]
    with open(output_file_path, 'w', encoding='utf-8', newline='') as file:
        file.writelines(processed_lines)
    
    # Create the sliders row and write to CSV
    sliders_row = create_sliders_row(input_file_path, lines)
    with open(sliders_file_path, 'w', encoding='utf-8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(sliders_row)
    
    return output_file_path, sliders_file_path

def process_folder(folder_path):
    """Process all CSV files in the specified folder."""
    processed_files = []
    
    for filename in os.listdir(folder_path):
        if filename.endswith('.csv') and '_raw' in filename:
            input_file_path = os.path.join(folder_path, filename)
            main_output_path, sliders_output_path = process_csv_file(input_file_path)
            processed_files.append((
                filename,
                os.path.basename(main_output_path),
                os.path.basename(sliders_output_path)
            ))
    
    return processed_files

if __name__ == "__main__":
    # Get the directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    try:
        processed_files = process_folder(script_dir)
        if processed_files:
            print(f"Successfully processed {len(processed_files)} files:")
            for input_file, output_file, sliders_file in processed_files:
                print(f"  {input_file} → {output_file} and {sliders_file}")
        else:
            print('No files with "_raw" found')
    except Exception as e:
        print(f"An error occurred: {str(e)}")