import os

def rename_files_and_folders():
    # Define the rename mappings
    rename_mapping = {
        "Zabrak": "ZabrakRep"
    }

    # Get the current working directory
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Rename CSV files in the current directory
    for filename in os.listdir(current_dir):
        if filename.endswith("_raw.csv") or filename.endswith("_sliders.csv"):
            new_filename = f"zzz_{filename}"
            os.rename(os.path.join(current_dir, filename), os.path.join(current_dir, new_filename))
        elif filename.endswith(".csv") and filename != "CharSliderLabels.csv":
            base, ext = os.path.splitext(filename)
            new_filename = f"{base}Rep{ext}"
            os.rename(os.path.join(current_dir, filename), os.path.join(current_dir, new_filename))

    # Rename folders in the "output" directory
    output_dir = os.path.join(current_dir, "output")
    for root, dirs, files in os.walk(output_dir):
        for dir_name in dirs:
            if dir_name in rename_mapping:
                old_path = os.path.join(root, dir_name)
                new_path = os.path.join(root, rename_mapping[dir_name])
                os.rename(old_path, new_path)

if __name__ == "__main__":
    rename_files_and_folders()
