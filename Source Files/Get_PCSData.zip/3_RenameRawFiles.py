import os

def rename_files_and_folders():

    # Get the current working directory
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Rename CSV files in the current directory
    for filename in os.listdir(current_dir):
        if filename.endswith("_raw.csv") or filename.endswith("_sliders.csv"):
            new_filename = f"zzz_{filename}"
            os.rename(os.path.join(current_dir, filename), os.path.join(current_dir, new_filename))

if __name__ == "__main__":
    rename_files_and_folders()
