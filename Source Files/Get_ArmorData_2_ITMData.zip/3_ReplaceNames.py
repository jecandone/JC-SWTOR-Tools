import json
import os
import re

def load_item_names(filename):
    """Load the ITMNameValues.json file and return as dictionary"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: {filename} not found!")
        return {}
    except json.JSONDecodeError:
        print(f"Error: {filename} is not valid JSON!")
        return {}

def process_json_file(input_file, item_names, output_dir):
    """Process a single JSON file and save the modified version"""
    try:
        # Read input file
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        def replace_item_ids(obj):
            """Recursively process JSON objects and replace item IDs"""
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if key == "value" and isinstance(value, str):
                        # Check for the pattern str.itm#number
                        match = re.match(r'str\.itm#(\d+)$', value)
                        if match:
                            item_id = match.group(1)
                            if item_id in item_names:
                                obj[key] = item_names[item_id]
                    elif isinstance(value, (dict, list)):
                        replace_item_ids(value)
            elif isinstance(obj, list):
                for item in obj:
                    if isinstance(item, (dict, list)):
                        replace_item_ids(item)
        
        # Process the JSON data
        replace_item_ids(data)
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Save processed file
        output_file = os.path.join(output_dir, os.path.basename(input_file))
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        
        print(f"Processed: {input_file} -> {output_file}")
        
    except Exception as e:
        print(f"Error processing {input_file}: {str(e)}")

def main():
    # Define directories
    current_dir = os.path.dirname(os.path.abspath(__file__))
    processed_dir = os.path.join(current_dir, "processed")
    named_dir = os.path.join(current_dir, "Named")
    item_names_file = os.path.join(current_dir, "ITMNameValues.json")
    
    # Load item names
    item_names = load_item_names(item_names_file)
    if not item_names:
        return
    
    # Process files in current directory
    for filename in os.listdir(current_dir):
        if filename.endswith('.json') and filename != "ITMNameValues.json":
            process_json_file(os.path.join(current_dir, filename), item_names, named_dir)
    
    # Process files in processed directory
    if os.path.exists(processed_dir):
        for filename in os.listdir(processed_dir):
            if filename.endswith('.json'):
                process_json_file(os.path.join(processed_dir, filename), item_names, named_dir)

if __name__ == "__main__":
    main()
