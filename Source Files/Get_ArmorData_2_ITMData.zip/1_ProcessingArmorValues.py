import os
import csv
import time
import json
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pyautogui
import psutil
import subprocess

def start_chrome_with_debugger():
    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    url = "https://swtor.jedipedia.net/reader"
    subprocess.Popen([chrome_path, f"--remote-debugging-port=9222", url])
    time.sleep(2)  # Wait for Chrome to start

def upload_tor_files(driver):
    try:
        print("Starting file upload process...")
        
        # Get list of all .tor files in the directory
        tor_files = [os.path.join('A:\\Games\\SWTOR\\Assets', f) for f in os.listdir('A:\\Games\\SWTOR\\Assets') if f.endswith('.tor')]
        
        # Find the hidden file input element
        file_input = driver.find_element(By.ID, "fileSelection")
        
        # Send all file paths to the input element
        driver.execute_script("arguments[0].style.display = 'block';", file_input)
        file_input.send_keys('\n'.join(tor_files))
        
        print("Waiting for files to load...")
        time.sleep(20)
        print("File upload process complete.")
    
    except Exception as e:
        print(f"Error in upload_tor_files: {str(e)}")
        raise e

# Function to check if browsers are running
def is_browser_running(browser_name):
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] and browser_name.lower() in proc.info['name'].lower():
            return True
    return False

# Function to check if the URL is open in the existing Chrome session
def is_url_open(url):
    options = Options()
    options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    driver = webdriver.Chrome(service=Service('C:\\Users\\Jeff\\Desktop\\testDirect\\chromedriver-win64\\chromedriver.exe'), options=options)
    
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if driver.current_url == url:
            return driver
    return None

# Function to execute JavaScript in the developer console
def execute_javascript(driver, node_name, file_path):
    # Ensure we're using the full path to the raw directory
    full_path = os.path.join(RAW_DIRECTORY, os.path.basename(file_path))
    
    script = f"""
    (function() {{
        let items = [];
        let lastCompletionValue = 0;
        let totalItems = 0;
        let lastUpdateTime = Date.now();
        let downloadTriggered = false;
        
        if (typeof readAllNodes === 'undefined') {{
            console.error('readAllNodes function not found');
            return;
        }}

        // Override the original console.log to capture completion messages
        const originalLog = console.log;
        console.log = function() {{
            const msg = Array.from(arguments).join(' ');
            originalLog.apply(console, arguments);  // Always log original message
            
            const match = msg.match(/Completed\\s+(\\d+)\\s+of\\s+(\\d+)/);
            if (match) {{
                const completed = parseInt(match[1]);
                const total = parseInt(match[2]);
                
                lastCompletionValue = completed;
                totalItems = total;
                lastUpdateTime = Date.now();
                
                originalLog.call(console, 'Progress tracked: ' + completed + ' of ' + total);
                window.pyLog = 'Progress: ' + completed + ' of ' + total;

                // If we detect total is less than 100, trigger download immediately
                if (total < 100 && !downloadTriggered) {{
                    downloadTriggered = true;
                    originalLog.call(console, 'Small dataset detected, waiting 10 seconds before download...');
                    
                    setTimeout(() => {{
                        originalLog.call(console, 'Initiating download...');
                        try {{
                            downloadJsonFile(items, '{os.path.basename(file_path)}');
                            originalLog.call(console, 'Download function executed');
                        }} catch(err) {{
                            console.error('Error during download:', err);
                        }}
                    }}, 10000);
                }}
            }}
        }};
        
        readAllNodes('{node_name}', (node, obj) => items.push({{node, obj}}));
        
        function downloadJsonFile(data, filename) {{
            const jsonStr = JSON.stringify(data);
            const blob = new Blob([jsonStr], {{ type: 'application/json' }});
            const link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.setAttribute('download', filename);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        }}

        console.log('Starting process for {node_name}');
        
        // Function to check completion status
        function checkCompletion() {{
            const currentTime = Date.now();
            const timeSinceLastUpdate = currentTime - lastUpdateTime;
            
            if (lastCompletionValue > 0 && timeSinceLastUpdate > 3000 && !downloadTriggered) {{
                originalLog.call(console, 'Checking completion: ' + lastCompletionValue + ' of ' + totalItems);
                
                // Only handle large datasets here (100 or more)
                if (totalItems >= 100) {{
                    const highestHundred = Math.floor(totalItems / 100) * 100;
                    
                    if (lastCompletionValue >= highestHundred) {{
                        downloadTriggered = true;
                        originalLog.call(console, 'Reached final completion: ' + lastCompletionValue + ' of ' + totalItems);
                        originalLog.call(console, 'Waiting 5 seconds before download...');
                        
                        setTimeout(() => {{
                            originalLog.call(console, 'Initiating download...');
                            try {{
                                downloadJsonFile(items, '{os.path.basename(file_path)}');
                                originalLog.call(console, 'Download function executed');
                            }} catch(err) {{
                                console.error('Error during download:', err);
                            }}
                        }}, 5000);
                        
                        clearInterval(checkInterval);
                    }}
                }}
            }}
        }}

        // Check completion status every second
        const checkInterval = setInterval(checkCompletion, 1000);
    }})();
    """
    
    print(f"Executing JavaScript for {node_name}")
    driver.execute_script(script)

    # Monitor for log messages from JavaScript
    def get_log_message():
        try:
            return driver.execute_script("const msg = window.pyLog; window.pyLog = null; return msg;")
        except:
            return None

    # Wait for potential completion with active logging
    wait_timeout = 180  # 3 minutes timeout
    start_time = time.time()
    
    while time.time() - start_time < wait_timeout:
        # Check for log messages
        log_msg = get_log_message()
        if log_msg:
            print(f"Browser Log: {log_msg}")

        # Check for save dialog
        if pyautogui.getWindowsWithTitle("Save As"):
            pyautogui.typewrite(full_path)
            pyautogui.press('enter')
            print(f"Save dialog handled for {node_name} - Saving to: {full_path}")
            break

        time.sleep(1)
    
    # Wait for the file to be saved
    save_timeout = 30
    start_time = time.time()
    while not os.path.exists(full_path):
        if time.time() - start_time > save_timeout:
            print(f"Timeout waiting for file to save: {full_path}")
            break
        time.sleep(1)

def process_json_file(input_file_path, mapping_file_path, output_directory):
    """Process a single JSON file with the given mapping file."""
    try:
        # Load the base JSON file
        with open(input_file_path, 'r') as file:
            base_data = json.load(file)

        # Load the mapping JSON file
        with open(mapping_file_path, 'r') as file:
            mapping_data = json.load(file)

        # Replace values in the base JSON
        updated_data = replace_values(base_data, mapping_data)

        # Create the output directory if it doesn't exist
        output_directory = Path(output_directory)
        output_directory.mkdir(exist_ok=True)

        # Create output filename by removing '_raw' from the input filename
        output_file_name = Path(input_file_path).name.replace('_raw.json', '.json')
        output_file_path = output_directory / output_file_name
        
        # Save the updated JSON file
        with open(output_file_path, 'w') as file:
            json.dump(updated_data, file, indent=4)

        print(f"Successfully processed and saved to '{output_file_path}'")
        
    except Exception as e:
        print(f"Error processing {input_file_path}: {str(e)}")

def process_directory(directory_path, mapping_file_path, output_directory):
    """Process all _raw.json files in the specified directory."""
    # Convert directory path to Path object
    dir_path = Path(directory_path)
    
    # Ensure directory exists
    if not dir_path.exists():
        raise ValueError(f"Directory not found: {directory_path}")
    
    # Ensure mapping file exists
    if not Path(mapping_file_path).exists():
        raise ValueError(f"Mapping file not found: {mapping_file_path}")

    # Find all JSON files in directory that end with _raw.json
    raw_files = list(dir_path.glob('*_raw.json'))
    
    if not raw_files:
        print(f"No '_raw.json' files found in {directory_path}")
        return

    print(f"Found {len(raw_files)} raw JSON files to process")
    
    # Process each file
    for file_path in raw_files:
        try:
            process_json_file(file_path, mapping_file_path, output_directory)
        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")

# Configuration
INPUT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))  # Use current directory
RAW_DIRECTORY = os.path.join(INPUT_DIRECTORY, 'raw')  # Raw files directory
PROCESSED_DIRECTORY = os.path.join(INPUT_DIRECTORY, 'processed')  # Processed files directory
MAPPING_FILE = r"GOM.fields.json"  # Path to your mapping file
CSV_FILE = os.path.join(INPUT_DIRECTORY, 'NodeMapping.csv')  # CSV file path

def replace_values(data, mapping):
    """
    Recursively replace values in the data structure according to the mapping
    """
    if isinstance(data, dict):
        return {key: replace_values(value, mapping) for key, value in data.items()}
    elif isinstance(data, list):
        return [replace_values(item, mapping) for item in data]
    elif isinstance(data, (int, float, str)):
        return mapping.get(data, data)
    else:
        return data

# Main function
def main():
    # Start Chrome with debugger
    start_chrome_with_debugger()
    
    url = "https://swtor.jedipedia.net/reader"
    browsers = ["chrome", "firefox", "msedge"]

    # Create directories if they don't exist
    os.makedirs(RAW_DIRECTORY, exist_ok=True)
    os.makedirs(PROCESSED_DIRECTORY, exist_ok=True)
    
    for browser in browsers:
        if is_browser_running(browser):
            driver = is_url_open(url)
            if driver:
                # Add the file upload functionality here
                upload_tor_files(driver)
                
                # Continue with your existing code
                with open(CSV_FILE, newline='') as csvfile:
                    reader = csv.reader(csvfile)
                    for row in reader:
                        node_name = ".".join([value for value in row if value])
                        file_name = f"{'_'.join(row)}_raw.json"
                        file_path = os.path.join(RAW_DIRECTORY, file_name)
                        execute_javascript(driver, node_name, file_path)
                        print(f"JavaScript commands executed for {node_name}.")
                        time.sleep(2)  # Wait for 2 seconds between attempts
                break
    else:
        print("The specified URL is not open in any supported browser.")

    # Process downloaded JSON files
    process_directory(RAW_DIRECTORY, MAPPING_FILE, PROCESSED_DIRECTORY)

if __name__ == "__main__":
    main()