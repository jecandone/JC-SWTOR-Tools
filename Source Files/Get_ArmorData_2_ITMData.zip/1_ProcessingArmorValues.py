import os
import csv
import time
import json
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import logging
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
INPUT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
RAW_DIRECTORY = os.path.join(INPUT_DIRECTORY, 'raw')
PROCESSED_DIRECTORY = os.path.join(INPUT_DIRECTORY, 'processed')
MAPPING_FILE = r"GOM.fields.json"
CSV_FILE = os.path.join(INPUT_DIRECTORY, 'NodeMapping.csv')

class SaveHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.info(f"Server Request: {format%args}")
    
    def handle_one_request(self):
        try:
            return super().handle_one_request()
        except ConnectionResetError:
            logger.warning("Client connection was reset")
        except Exception as e:
            logger.error(f"Error handling request: {str(e)}")
    
    def handle(self):
        try:
            return super().handle()
        except ConnectionResetError:
            logger.warning("Client connection was reset during handling")
        except Exception as e:
            logger.error(f"Error in connection handling: {str(e)}")
        
    def do_POST(self):
        try:
            start_time = time.time()
            logger.info("Received POST request")
            
            try:
                content_length = int(self.headers['Content-Length'])
            except (KeyError, ValueError) as e:
                logger.error(f"Invalid Content-Length header: {str(e)}")
                self.send_error(400, "Invalid Content-Length header")
                return
            
            try:
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON data: {str(e)}")
                self.send_error(400, "Invalid JSON data")
                return
            except Exception as e:
                logger.error(f"Error reading POST data: {str(e)}")
                self.send_error(500, "Error reading POST data")
                return
            
            file_path = os.path.join(RAW_DIRECTORY, data['filename'])
            logger.info(f"Saving file to: {file_path}")
            
            try:
                with open(file_path, 'w') as f:
                    json.dump(data['content'], f)
            except Exception as e:
                logger.error(f"Error saving file: {str(e)}")
                self.send_error(500, "Error saving file")
                return
            
            try:
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'success'}).encode())
            except Exception as e:
                logger.error(f"Error sending response: {str(e)}")
                return
            
            elapsed_time = time.time() - start_time
            logger.info(f"POST request completed in {elapsed_time:.2f} seconds")
            
        except Exception as e:
            logger.error(f"Unexpected error in do_POST: {str(e)}")
            try:
                self.send_error(500, "Internal Server Error")
            except:
                pass

    def do_OPTIONS(self):
        try:
            logger.info("Received OPTIONS request")
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'POST')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
        except Exception as e:
            logger.error(f"Error handling OPTIONS request: {str(e)}")
            try:
                self.send_error(500, "Internal Server Error")
            except:
                pass

def start_save_server():
    logger.info("Starting save server...")
    start_time = time.time()
    
    class QuickTimeoutHTTPServer(HTTPServer):
        timeout = 1
        
    server = QuickTimeoutHTTPServer(('localhost', 8000), SaveHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    
    elapsed_time = time.time() - start_time
    logger.info(f"Server started in {elapsed_time:.2f} seconds")
    return server, server_thread

def shutdown_server(server, server_thread):
    logger.info("Beginning server shutdown sequence...")
    shutdown_start = time.time()
    
    try:
        server.socket.settimeout(1)
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=2)
    except Exception as e:
        logger.error(f"Error during server shutdown: {e}")
    
    logger.info(f"Server shutdown completed in {time.time() - shutdown_start:.2f} seconds")

def setup_headless_driver():
    """Setup and return a headless Chrome WebDriver"""
    options = Options()
    options.add_argument('--headless=new')  # Use the new headless mode
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_argument('--window-size=1920,1080')
    options.add_argument('--remote-debugging-address=0.0.0.0')  # Listen on all interfaces
    options.add_argument('--remote-debugging-port=0')  # Let Chrome pick an available port
    options.add_experimental_option('excludeSwitches', ['enable-logging'])  # Reduce noise in output
    
    # Additional options to help with stability
    options.add_argument('--disable-extensions')
    options.add_argument('--disable-software-rasterizer')
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--allow-running-insecure-content')
    
    service = Service('C:\\Users\\TestUser\\Desktop\\testDirect\\chromedriver-win64\\chromedriver.exe')
    service.creation_flags = 0x08000000  # Detached process flag
    
    try:
        driver = webdriver.Chrome(service=service, options=options)
        driver.set_page_load_timeout(30)  # Set page load timeout
        return driver
    except Exception as e:
        logger.error(f"Failed to create Chrome driver: {str(e)}")
        raise
    
    return driver

def upload_tor_files(driver):
    try:
        logger.info("Starting file upload process...")
        
        # Navigate to the target URL
        driver.get("https://swtor.jedipedia.net/reader")
        logger.info("Navigated to target URL")
        
        # Wait for page to load and be interactive
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "fileSelection"))
        )
        
        # Get list of all .tor files
        tor_files = [os.path.join('A:\\Games\\SWTOR\\Assets', f) 
                    for f in os.listdir('A:\\Games\\SWTOR\\Assets') 
                    if f.endswith('.tor')]
        logger.info(f"Found {len(tor_files)} .tor files")
        
        # Upload files
        file_input = driver.find_element(By.ID, "fileSelection")
        driver.execute_script("arguments[0].style.display = 'block';", file_input)
        file_input.send_keys('\n'.join(tor_files))
        
        logger.info("Waiting for files to load...")
        time.sleep(20)  # Adjust this wait time based on your needs
        logger.info("File upload process complete")
        
    except Exception as e:
        logger.error(f"Error in upload_tor_files: {str(e)}")
        raise e

def execute_javascript(driver, node_name, file_path):
    logger.info(f"Executing JavaScript for {node_name}")
    script = f"""
    (function() {{
        let items = [];
        let lastCompletionValue = 0;
        let totalItems = 0;
        let lastUpdateTime = Date.now();
        let downloadTriggered = false;
        
        if (typeof readAllNodes === 'undefined') {{
            console.error('readAllNodes function not found');
            return;
        }}

        const originalLog = console.log;
        console.log = function() {{
            const msg = Array.from(arguments).join(' ');
            originalLog.apply(console, arguments);
            
            const match = msg.match(/Completed\\s+(\\d+)\\s+of\\s+(\\d+)/);
            if (match) {{
                const completed = parseInt(match[1]);
                const total = parseInt(match[2]);
                
                lastCompletionValue = completed;
                totalItems = total;
                lastUpdateTime = Date.now();
                
                originalLog.call(console, 'Progress tracked: ' + completed + ' of ' + total);
                window.pyLog = 'Progress: ' + completed + ' of ' + total;

                if (total < 100 && !downloadTriggered) {{
                    downloadTriggered = true;
                    setTimeout(() => {{
                        try {{
                            saveJsonFile(items, '{os.path.basename(file_path)}');
                        }} catch(err) {{
                            console.error('Error during save:', err);
                        }}
                    }}, 10000);
                }}
            }}
        }};
        
        readAllNodes('{node_name}', (node, obj) => items.push({{node, obj}}));
        
        async function saveJsonFile(data, filename) {{
            try {{
                const response = await fetch('http://localhost:8000', {{
                    method: 'POST',
                    headers: {{
                        'Content-Type': 'application/json',
                    }},
                    body: JSON.stringify({{
                        filename: filename,
                        content: data
                    }})
                }});
                
                if (!response.ok) {{
                    throw new Error(`HTTP error! status: ${{response.status}}`);
                }}
                
                const result = await response.json();
                console.log('Save successful:', result);
                window.pyLog = 'Save completed for ' + filename;
            }} catch (error) {{
                console.error('Error saving file:', error);
                window.pyLog = 'Error saving file: ' + error.message;
            }}
        }}

        function checkCompletion() {{
            const currentTime = Date.now();
            const timeSinceLastUpdate = currentTime - lastUpdateTime;
            
            if (lastCompletionValue > 0 && timeSinceLastUpdate > 3000 && !downloadTriggered) {{
                if (totalItems >= 100) {{
                    const highestHundred = Math.floor(totalItems / 100) * 100;
                    
                    if (lastCompletionValue >= highestHundred) {{
                        downloadTriggered = true;
                        setTimeout(() => {{
                            try {{
                                saveJsonFile(items, '{os.path.basename(file_path)}');
                            }} catch(err) {{
                                console.error('Error during save:', err);
                            }}
                        }}, 5000);
                        
                        clearInterval(checkInterval);
                    }}
                }}
            }}
        }}

        const checkInterval = setInterval(checkCompletion, 1000);
    }})();
    """
    
    driver.execute_script(script)

    def get_log_message():
        try:
            return driver.execute_script("const msg = window.pyLog; window.pyLog = null; return msg;")
        except:
            return None

    wait_timeout = 180
    start_time = time.time()
    
    while time.time() - start_time < wait_timeout:
        log_msg = get_log_message()
        if log_msg:
            logger.info(f"Browser Log: {log_msg}")
            if 'Save completed for' in log_msg:
                break
        time.sleep(1)

def process_json_file(input_file_path, mapping_file_path, output_directory):
    """Process a single JSON file with the given mapping file."""
    try:
        logger.info(f"Processing file: {input_file_path}")
        process_start = time.time()

        # Load the base JSON file
        with open(input_file_path, 'r') as file:
            base_data = json.load(file)

        # Load the mapping JSON file
        with open(mapping_file_path, 'r') as file:
            mapping_data = json.load(file)

        # Replace values in the base JSON
        updated_data = replace_values(base_data, mapping_data)

        # Create the output directory if it doesn't exist
        output_directory = Path(output_directory)
        output_directory.mkdir(exist_ok=True)

        # Create output filename
        output_file_name = Path(input_file_path).name.replace('_raw.json', '.json')
        output_file_path = output_directory / output_file_name
        
        # Save the updated JSON file
        with open(output_file_path, 'w') as file:
            json.dump(updated_data, file, indent=4)

        process_time = time.time() - process_start
        logger.info(f"Successfully processed and saved to '{output_file_path}' in {process_time:.2f} seconds")
        
    except Exception as e:
        logger.error(f"Error processing {input_file_path}: {str(e)}")

def process_directory(directory_path, mapping_file_path, output_directory):
    """Process all _raw.json files in the specified directory."""
    dir_path = Path(directory_path)
    
    if not dir_path.exists():
        raise ValueError(f"Directory not found: {directory_path}")
    
    if not Path(mapping_file_path).exists():
        raise ValueError(f"Mapping file not found: {mapping_file_path}")

    raw_files = list(dir_path.glob('*_raw.json'))
    
    if not raw_files:
        logger.warning(f"No '_raw.json' files found in {directory_path}")
        return

    logger.info(f"Found {len(raw_files)} raw JSON files to process")
    
    for file_path in raw_files:
        try:
            process_json_file(file_path, mapping_file_path, output_directory)
        except Exception as e:
            logger.error(f"Error processing {file_path}: {str(e)}")

def replace_values(data, mapping):
    """Recursively replace values in the data structure using the mapping."""
    if isinstance(data, dict):
        return {key: replace_values(value, mapping) for key, value in data.items()}
    elif isinstance(data, list):
        return [replace_values(item, mapping) for item in data]
    elif isinstance(data, (int, float, str)):
        return mapping.get(data, data)
    else:
        return data

def main():
    logger.info("Starting main process...")
    start_time = time.time()
    
    server, server_thread = start_save_server()
    driver = None
    
    try:
        # Create directories if they don't exist
        os.makedirs(RAW_DIRECTORY, exist_ok=True)
        os.makedirs(PROCESSED_DIRECTORY, exist_ok=True)
        
        # Initialize headless Chrome
        logger.info("Starting headless Chrome...")
        driver = setup_headless_driver()
        
        # Upload tor files
        upload_start_time = time.time()
        upload_tor_files(driver)
        logger.info(f"File upload completed in {time.time() - upload_start_time:.2f} seconds")
        
        # Process CSV and execute JavaScript for each node
        with open(CSV_FILE, newline='') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                node_name = ".".join([value for value in row if value])
                file_name = f"{'_'.join(row)}_raw.json"
                file_path = os.path.join(RAW_DIRECTORY, file_name)
                
                # Print distinctive start marker
                print("\n---------------------------------------")
                print(f"Begin Processing Node: {node_name}")
                print("---------------------------------------")
                
                # Log the standard processing message
                logger.info(f"Processing node: {node_name}")
                
                # Process the node
                node_start_time = time.time()
                execute_javascript(driver, node_name, file_path)
                processing_time = time.time() - node_start_time
                
                # Log the completion message
                logger.info(f"Node {node_name} processed in {processing_time:.2f} seconds")
                
                # Print distinctive end marker
                print("\n---------------------------------------")
                print(f"End Processing Node: {node_name}")
                print("---------------------------------------\n")
                
                time.sleep(2)
        
        # Process downloaded JSON files if needed
        if os.path.exists(MAPPING_FILE):
            processing_start_time = time.time()
            process_directory(RAW_DIRECTORY, MAPPING_FILE, PROCESSED_DIRECTORY)
            logger.info(f"JSON processing completed in {time.time() - processing_start_time:.2f} seconds")
        
    except Exception as e:
        logger.error(f"Error in main process: {e}", exc_info=True)
        
    finally:
        logger.info("\nStarting cleanup process...")
        cleanup_start_time = time.time()
        
        if driver:
            try:
                driver.quit()
                logger.info("Browser closed successfully")
            except Exception as e:
                logger.error(f"Error closing browser: {e}")

        shutdown_server(server, server_thread)
        
        total_time = time.time() - start_time
        logger.info(f"Total script execution time: {total_time:.2f} seconds")
        logger.info("Script completed successfully!")

if __name__ == "__main__":
    main()