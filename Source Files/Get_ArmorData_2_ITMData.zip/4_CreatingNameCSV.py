import json
import csv
import os
from pathlib import Path

def extract_values_from_json(json_obj):
    """
    Extract required values from a single JSON object.
    
    Args:
        json_obj (dict): JSON object to process
        
    Returns:
        dict: Dictionary containing extracted values or None if not all values are found
    """
    current_entry = {
        'icon_value': None,
        'file_name': None,
        'display_name': None
    }
    
    # Extract fileName from node section
    if 'node' in json_obj:
        current_entry['file_name'] = json_obj['node'].get('fileName')
    
    # Process obj array for icon and display name
    if 'obj' in json_obj:
        for item in json_obj['obj']:
            # Get icon value
            if item.get('id') == 'itmIcon':
                current_entry['icon_value'] = item.get('value')
            
            # Get display name (only from type 6 entries)
            if (item.get('id') == 'strLocalizedTextRetrieverStringID' and 
                item.get('type') == 6 and 
                isinstance(item.get('value'), str)):
                current_entry['display_name'] = item.get('value')
    
    # Return None if any required value is missing
    if not all(current_entry.values()):
        return None
        
    return current_entry

def process_json_file(file_path):
    """
    Process a single JSON file and extract values.
    
    Args:
        file_path (Path): Path to the JSON file
        
    Returns:
        list: List of extracted data entries
    """
    extracted_data = []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
            # If the data is a list, process each item
            if isinstance(data, list):
                json_objects = data
            else:
                json_objects = [data]
            
            # Process each JSON object
            for json_obj in json_objects:
                entry = extract_values_from_json(json_obj)
                if entry:
                    extracted_data.append([
                        entry['icon_value'],
                        entry['file_name'],
                        entry['display_name']
                    ])
                    
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
    
    return extracted_data

def process_all_json_files(base_dir):
    """
    Process all JSON files in the base directory and its 'Named' subdirectory.
    
    Args:
        base_dir (Path): Base directory to start searching from
        
    Returns:
        list: Combined list of all extracted data
    """
    all_data = []
    
    # Process JSON files in base directory
    for json_file in base_dir.glob('*.json'):
        all_data.extend(process_json_file(json_file))
    
    # Process JSON files in Named subdirectory
    named_dir = base_dir / 'Named'
    if named_dir.exists():
        for json_file in named_dir.glob('*.json'):
            all_data.extend(process_json_file(json_file))
    
    return all_data

def main():
    # Get the directory where the script is located
    script_dir = Path(os.path.dirname(os.path.abspath(__file__)))
    output_file = script_dir / 'ArmorNodes_Names.csv'
    
    try:
        # Process all JSON files and combine the data
        all_extracted_data = process_all_json_files(script_dir)
        
        # Write all data to a single CSV file
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            # Write all extracted data without header
            writer.writerows(all_extracted_data)
            
        print(f"Successfully processed all JSON files and created {output_file}")
        print(f"Total entries processed: {len(all_extracted_data)}")
        
    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()