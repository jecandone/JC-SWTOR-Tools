------------------------------------------------------------------------------------------------------
Step 2 - Getting ITM Data
------------------------------------------------------------------------------------------------------

Use Tools in Zip File: Get_ArmorData_2_IPPData.zip

Pre-Reqs:

Chrome Driver - need a version of chrome driver to be able to run the python file (https://googlechromelabs.github.io/chrome-for-testing/) - make sure to download the "chromedriver"

CSV File of Nodes - needs a CSV file to tell the script what nodes to process - trying to process the entire "ipp" node at a time can often lead to crashing, so breaking this up (ie into each node within the ipp node) does not lead to the same issues and is recommended.

Property ID Translation File - needs a .json file to process the "untranslated" property ID fields - will replace any string it finds on the left hand side of the file with the translated name on the right hand side file.  To get updated translations:

	1) Go to Jedipedia File Reader, go to the node tab.
	2) Open up the developer console (ie F12 on chrome), and run the following command:

	copy(Object.entries(GOM.fields).map(t => t.join('\t')).join('\n'))

	3) This creates a JSON file that is copied to the clipboard - paste this into a new file, and save it as a .json file

ITM ID Translation File - needs a .json file to process the "untranslated" ITM ID field - will replace any string it finds on the left hand side of the file with the translated name (ie in-game name) on the right hand side of the file.  To get updated translations:

	1) Go to Jedipedia File Reader, go to the node tab.
	2) Open up the developer console (ie F12 on chrome), and run the following command:

	copy(stb['str.itm']);

	3) This creates a JSON file that is copied to the clipboard - paste this into a new file, and save it as a .json file 

Author Note: I ran this in Windows Powershell (ie python [python file]) - the system needs the below to run, if they're not installed in your system, they can be installed via typing in the commands below:

	pip install selenium

1) 1_ProcessingArmorValues.py

Input: .TOR file directory [tor_files = [os.path.join('A:\\Games\\SWTOR\\Assets', f) for f in os.listdir('A:\\Games\\SWTOR\\Assets') if f.endswith('.tor')]']
Input:  Chrome Driver Directory [service = Service('service = Service('C:\\Users\\TestUser\\Desktop\\testDirect\\chromedriver-win64\\chromedriver.exe']
Input: CSV file of nodes [CSV_FILE = os.path.join(INPUT_DIRECTORY, 'NodeMapping.csv')]
Input: Property ID Translation File [MAPPING_FILE = r"GOM.fields.json"]

Downloads all untranslated node data for all files in the "itm" node section to "raw" folder

2) 2_json-field-replacer.py

Input: Name Translation File ('fields_mapping = load_json_file('GOM.fields.json')')

Replaces the property IDs from the downloaded JSON files with translated names, created an output in the "processed" folder

3) 3_ReplaceNames.py

Input: ITM Translation File ('item_names_file = os.path.join(current_dir, "ITMNameValues.json")')

Replaces the ITM IDs from the downloaded JSON files in the "processed" folder with the translate ITM names, and saves new file to the "Named" folder.


4) 4_CreatingNameCSV.py

Creates a file "ArmorNodes_Names.csv" - a CSV file with three columns:

Column #1: Armor FQN Name
Column #2: Slot (leg, chest, etc)
Column #3: In-Game Name

NOTE: All four of the .py file need any of their inputs updated, but instead of running each file individually, one can run the file "" to run all four of them in sequence.  
