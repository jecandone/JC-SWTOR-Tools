------------------------------------------------------------------------------------------------------
Step 1 - Getting IPP Data
------------------------------------------------------------------------------------------------------

Use Tools in Zip File: Get_ArmorData_1_IPPData.zip

Pre-Reqs:

Chrome Driver - need a version of chrome driver to be able to run the python file (https://googlechromelabs.github.io/chrome-for-testing/) - make sure to download the "chromedriver"

CSV File of Nodes - needs a CSV file to tell the script what nodes to process - trying to process the entire "ipp" node at a time can often lead to crashing, so breaking this up (ie into each node within the ipp node) does not lead to the same issues and is recommended.

Property ID Translation File - needs a .json file to process the "untranslated" property ID fields - will replace any string it finds on the left hand side of the file with the translated name on the right hand side file.  To get updated translations:

	1) Go to Jedipedia File Reader, go to the node tab.
	2) Open up the developer console (ie F12 on chrome), and run the following command:

	copy(Object.entries(GOM.fields).map(t => t.join('\t')).join('\n'))

	3) This creates a JSON file that is copied to the clipboard - paste this into a new file, and save it as a .json file


Author Note: I ran this in Windows Powershell (ie python [python file]) - the system needs the below to run, if they're not installed in your system, they can be installed via typing in the commands below:

	pip install selenium

1) 1_ProcessingArmorValues.py

Input: .TOR file directory [tor_files = [os.path.join('A:\\Games\\SWTOR\\Assets', f) for f in os.listdir('A:\\Games\\SWTOR\\Assets') if f.endswith('.tor')]']
Input:  Chrome Driver Directory [service = Service('service = Service('C:\\Users\\TestUser\\Desktop\\testDirect\\chromedriver-win64\\chromedriver.exe']
Input: CSV file of nodes [CSV_FILE = os.path.join(INPUT_DIRECTORY, 'NodeMapping.csv')]
Input: Property ID Translation File [MAPPING_FILE = r"GOM.fields.json"]

Downloads all untranslated node data for all files in the "ipp" node section to "raw" folder


2) 2_json-field-replacer.py

Input: Name Translation File [fields_mapping = load_json_file('GOM.fields.json')]

Replaces the property IDs from the downloaded JSON files with translated names, created an output in the "processed" folder

3) 3_ConvertToCSV.py

Creates "ippArmorValues.csv" file - contains a CSV with the following columns:

Column #1: Armor FQN Name
Column #2: Display Name
Column #3: Slot (ie leg, hand, etc)
Column #4: Model ID
Column #5: Color Scheme ID
Column #6: Material IID

4) Place the newly created CSV file ("ippArmorValues.csv") into the "ArmorIPP" folder of the plugin.


OPTIONAL: All inputs need to be updated for your file path, but once done, can run the single script "RunAll_GettingIPP.py" to run all three files in order.  
