import json
import csv
import os
from pathlib import Path

def extract_name_from_fqn(fqn):
    """
    Extract the name between the last and second last period from the fqn.
    Example: from 'ipp.mtx.season5.kreia.waist' returns 'kreia'
    """
    parts = fqn.split('.')
    if len(parts) >= 2:
        return parts[-2]
    return ''

def process_json_files(folder_path, output_filename):
    """
    Process all JSON files in the specified folder and create a CSV file with extracted data.
    
    Args:
        folder_path (str): Path to folder containing JSON files
        output_filename (str): Name of the output CSV file
    """
    # Convert folder path to Path object for better cross-platform compatibility
    folder = Path(folder_path)
    output_file = folder.parent / output_filename
    
    # List to store all extracted data
    all_data = []
    
    # Process each JSON file in the folder
    for json_file in folder.glob('*.json'):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                content = f.read()
                # Clean up the content - remove trailing commas and wrap in array
                content = content.strip()
                if content.endswith(','):
                    content = content[:-1]
                if not content.startswith('['):
                    content = '[' + content + ']'
                
                data = json.loads(content)
                
                # Handle both single object and list of objects
                if isinstance(data, dict):
                    data = [data]
                
                # Process each node in the JSON file
                for item in data:
                    if 'node' not in item or 'obj' not in item:
                        continue
                        
                    node = item['node']
                    obj = item['obj']
                    
                    # Check if baseClass matches the required value
                    if node.get('baseClass') == '4611686022221010000':
                        # Extract fqn and fileName from node
                        fqn = node.get('fqn', '')
                        name = extract_name_from_fqn(fqn)  # Extract name from fqn
                        filename = node.get('fileName', '')
                        
                        # Initialize variables for modelID, colorScheme, and materialIndex
                        model_id = ''
                        color_scheme = ''
                        material_index = ''
                        
                        # Extract modelID, colorScheme, and materialIndex from obj
                        for obj_item in obj:
                            if obj_item['id'] == 'appAppearanceSlotModelID':
                                model_id = str(obj_item['value']['intLo'])
                            elif obj_item['id'] == 'ippColorScheme':
                                color_scheme = str(obj_item['value']['intLo'])
                            elif obj_item['id'] == 'appAppearanceSlotMaterialIndex':
                                material_index = str(obj_item['value']['intLo'])
                        
                        # Add extracted data to results
                        all_data.append([fqn, name, filename, model_id, color_scheme, material_index])
        
        except Exception as e:
            print(f"Error processing file {json_file}: {str(e)}")
            # Print the first 100 characters of the file content for debugging
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    print(f"File start: {f.read(100)}...")
            except:
                pass
            continue
    
    # Write data to CSV file
    if all_data:
        try:
            with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
                csv_writer = csv.writer(csvfile)
                for row in all_data:
                    csv_writer.writerow(row)
            print(f"Successfully created CSV file: {output_file}")
            print(f"Processed {len(all_data)} entries")
        except Exception as e:
            print(f"Error writing CSV file: {str(e)}")
    else:
        print("No valid data found to write to CSV.")

def main():
    # Get the current directory
    current_dir = Path(__file__).resolve().parent
    folder_path = current_dir / "processed"
    output_filename = current_dir / "ippArmorValues.csv"
    
    print(f"Using folder: {folder_path}")
    print(f"Output filename set to: {output_filename}")
    
    # Validate folder path
    if not folder_path.is_dir():
        print(f"Error: The folder path '{folder_path}' does not exist or is not accessible.")
        return
    
    # Process the files
    process_json_files(folder_path, output_filename)

if __name__ == "__main__":
    main()