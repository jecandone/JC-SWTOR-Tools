import json
import glob
import os
import re

def clean_json_content(content):
    """Clean JSON content by removing trailing commas"""
    # Remove trailing commas in objects
    content = re.sub(r',(\s*})', r'\1', content)
    # Remove trailing commas in arrays
    content = re.sub(r',(\s*])', r'\1', content)
    return content

def load_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        # Clean the JSON content before parsing
        cleaned_content = clean_json_content(content)
        try:
            return json.loads(cleaned_content)
        except json.JSONDecodeError as e:
            print(f"\nJSON Error in {file_path}:")
            print(f"Error message: {str(e)}")
            raise

def replace_fields():
    # Load the GOM fields mapping
    print("Loading GOM.fields.json...")
    fields_mapping = load_json_file('GOM.fields.json')
    print("Successfully loaded field mappings")
    
    # Find all *_raw.json files in the "raw" folder only
    raw_folder_files = glob.glob('raw/*_raw.json')
    
    if not raw_folder_files:
        print("No *_raw.json files found in the 'raw' folder!")
        return
    
    # Ensure the "processed" subfolder exists
    os.makedirs('processed', exist_ok=True)
    
    for raw_file in raw_folder_files:
        print(f"\nProcessing {raw_file}...")
        
        # Load and process the raw file
        data = load_json_file(raw_file)
        
        def replace_values(obj):
            if isinstance(obj, dict):
                return {k: replace_values(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_values(item) for item in obj]
            elif isinstance(obj, str) and obj in fields_mapping:
                return fields_mapping[obj]
            return obj
        
        processed_data = replace_values(data)
        output_file = os.path.join('processed', os.path.basename(raw_file).replace('_raw.json', '.json'))
        
        # Save the processed data
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(processed_data, f, indent=4, sort_keys=True)
        
        print(f"Successfully created {output_file}")

if __name__ == "__main__":
    try:
        replace_fields()
        print("\nProcessing completed successfully!")
    except Exception as e:
        print(f"\nScript stopped due to error: {str(e)}")
