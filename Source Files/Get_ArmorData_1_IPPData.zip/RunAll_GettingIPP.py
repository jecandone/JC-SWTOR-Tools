import subprocess

# List of Python files to run
python_files = [
    '1_ProcessingArmorValues.py',
    '2_json-field-replacer.py',
    '3_ConvertToCSV.py'
]

print(f"\n\n\n")
print(f"---------------------------")
print(f"---------------------------")
print(f"---------------------------")
print(f"Begin Running Get IPP Process")
print(f"---------------------------")
print(f"---------------------------")
print(f"---------------------------")
print(f"\n\n\n")

for file in python_files:
    print(f"\n\n")
    print(f"---------------------------")
    print(f"Begin Running: {file}")
    print(f"---------------------------")
    print(f"\n\n")
    subprocess.run(['python', file])
    print(f"\n\n")
    print(f"---------------------------")
    print(f"End Running: {file}")
    print(f"---------------------------")
    print(f"\n\n")

print(f"\n\n\n")
print(f"---------------------------")
print(f"---------------------------")
print(f"---------------------------")
print(f"End Running Get IPP Process")
print(f"---------------------------")
print(f"---------------------------")
print(f"---------------------------")
print(f"\n\n\n")
